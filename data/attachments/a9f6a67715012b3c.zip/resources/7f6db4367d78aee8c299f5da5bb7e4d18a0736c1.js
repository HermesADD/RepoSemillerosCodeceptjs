/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/json-stringify-safe/stringify.js"
/*!*******************************************************!*\
  !*** ./node_modules/json-stringify-safe/stringify.js ***!
  \*******************************************************/
(module, exports) {

eval("{exports = module.exports = stringify\nexports.getSerialize = serializer\n\nfunction stringify(obj, replacer, spaces, cycleReplacer) {\n  return JSON.stringify(obj, serializer(replacer, cycleReplacer), spaces)\n}\n\nfunction serializer(replacer, cycleReplacer) {\n  var stack = [], keys = []\n\n  if (cycleReplacer == null) cycleReplacer = function(key, value) {\n    if (stack[0] === value) return \"[Circular ~]\"\n    return \"[Circular ~.\" + keys.slice(0, stack.indexOf(value)).join(\".\") + \"]\"\n  }\n\n  return function(key, value) {\n    if (stack.length > 0) {\n      var thisPos = stack.indexOf(this)\n      ~thisPos ? stack.splice(thisPos + 1) : stack.push(this)\n      ~thisPos ? keys.splice(thisPos, Infinity, key) : keys.push(key)\n      if (~stack.indexOf(value)) value = cycleReplacer.call(this, key, value)\n    }\n    else stack.push(value)\n\n    return replacer == null ? value : replacer.call(this, key, value)\n  }\n}\n\n\n//# sourceURL=webpack://ga4events.jewelml.io/./node_modules/json-stringify-safe/stringify.js?\n}");

/***/ },

/***/ "./client/get-deep-value.ts"
/*!**********************************!*\
  !*** ./client/get-deep-value.ts ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   getDeepValue: () => (/* binding */ getDeepValue)\n/* harmony export */ });\n// This is based on the lib deep-get-set\n// The original lib is written in JS. I extracted only the necessary functions and converted to TS\n// Original lib code: https://github.com/acstll/deep-get-set/blob/master/index.cjs\nfunction getDeepValue(obj, path) {\n    var keys = Array.isArray(path) ? path : path.split('.');\n    for (var i = 0; i < keys.length; i++) {\n        var key = keys[i];\n        if (!obj || !Object.prototype.hasOwnProperty.call(obj, key) || isUnsafeKey(key)) {\n            obj = undefined;\n            break;\n        }\n        obj = obj[key];\n    }\n    return obj;\n}\nfunction isUnsafeKey(key) {\n    return (Array.isArray(key) && key[0] === '__proto__')\n        || key === '__proto__'\n        || key === 'constructor'\n        || key === 'prototype';\n}\n\n\n\n//# sourceURL=webpack://ga4events.jewelml.io/./client/get-deep-value.ts?\n}");

/***/ },

/***/ "./client/index.ts"
/*!*************************!*\
  !*** ./client/index.ts ***!
  \*************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var json_stringify_safe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! json-stringify-safe */ \"./node_modules/json-stringify-safe/stringify.js\");\n/* harmony import */ var json_stringify_safe__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(json_stringify_safe__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! uuid */ \"./node_modules/uuid/dist/esm-browser/v4.js\");\n/* harmony import */ var _get_deep_value__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./get-deep-value */ \"./client/get-deep-value.ts\");\nvar __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {\n    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }\n    return new (P || (P = Promise))(function (resolve, reject) {\n        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }\n        function rejected(value) { try { step(generator[\"throw\"](value)); } catch (e) { reject(e); } }\n        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }\n        step((generator = generator.apply(thisArg, _arguments || [])).next());\n    });\n};\nvar __generator = (undefined && undefined.__generator) || function (thisArg, body) {\n    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;\n    return g = { next: verb(0), \"throw\": verb(1), \"return\": verb(2) }, typeof Symbol === \"function\" && (g[Symbol.iterator] = function() { return this; }), g;\n    function verb(n) { return function (v) { return step([n, v]); }; }\n    function step(op) {\n        if (f) throw new TypeError(\"Generator is already executing.\");\n        while (g && (g = 0, op[0] && (_ = 0)), _) try {\n            if (f = 1, y && (t = op[0] & 2 ? y[\"return\"] : op[0] ? y[\"throw\"] || ((t = y[\"return\"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;\n            if (y = 0, t) op = [op[0] & 2, t.value];\n            switch (op[0]) {\n                case 0: case 1: t = op; break;\n                case 4: _.label++; return { value: op[1], done: false };\n                case 5: _.label++; y = op[1]; op = [0]; continue;\n                case 7: op = _.ops.pop(); _.trys.pop(); continue;\n                default:\n                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }\n                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }\n                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }\n                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }\n                    if (t[2]) _.ops.pop();\n                    _.trys.pop(); continue;\n            }\n            op = body.call(thisArg, _);\n        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }\n        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };\n    }\n};\nvar __spreadArray = (undefined && undefined.__spreadArray) || function (to, from, pack) {\n    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {\n        if (ar || !(i in from)) {\n            if (!ar) ar = Array.prototype.slice.call(from, 0, i);\n            ar[i] = from[i];\n        }\n    }\n    return to.concat(ar || Array.prototype.slice.call(from));\n};\n\n\n\n(function () {\n    function isArgumentList(value) {\n        try {\n            return value && Object.hasOwnProperty.call(value, 'callee');\n        }\n        catch (err) {\n            return false;\n        }\n    }\n    var OPERATION_MODE = \"production\";\n    var INTEGRATION_ID = \"67fd95260740ccc4ec658d03\";\n    var API_BASE_URL = \"https://ga4events.jewelml.io/m\";\n    var REQUIRED_EVENT_PROPERTIES = null;\n    try {\n        REQUIRED_EVENT_PROPERTIES = JSON.parse(\"{'event':['productDetail','productClick','addToCart','removeFromCart','checkout','purchase','jewel_carousel_click','jewel_cart_click','jewel_favorite_click','jewel_view_item'],'pdp_view':['vPageview']}\".replace(/'/g, \"\\\"\"));\n    }\n    catch (err) { }\n    var EXCLUDED_PAYLOAD_KEYS = null;\n    try {\n        EXCLUDED_PAYLOAD_KEYS = JSON.parse(\"{}\".replace(/'/g, \"\\\"\"));\n    }\n    catch (err) { }\n    var DEFAULT_EVENTS = {\n        jewel_pdp_view: true,\n        jewel_cart_click: true,\n        jewel_carousel_click: true,\n        jewel_favorite_click: true,\n    };\n    function stripExcludedKeys(obj, keys, path) {\n        if (path === void 0) { path = ''; }\n        if (!obj || typeof obj !== 'object')\n            return obj;\n        if (Array.isArray(obj))\n            return obj.map(function (item) { return stripExcludedKeys(item, keys, path); });\n        var result = {};\n        for (var k in obj) {\n            var fullPath = path ? path + '.' + k : k;\n            if (keys[k] || keys[fullPath])\n                continue;\n            result[k] = stripExcludedKeys(obj[k], keys, fullPath);\n        }\n        return result;\n    }\n    var logEvent = function (payload) { return __awaiter(void 0, void 0, void 0, function () {\n        var uniqueId, userId, uniqueIdType, beaconSent;\n        return __generator(this, function (_a) {\n            switch (_a.label) {\n                case 0:\n                    uniqueId = '';\n                    userId = '';\n                    try {\n                        userId = localStorage.getItem(\"jml_userid_\".concat(INTEGRATION_ID));\n                        uniqueId = localStorage.getItem(\"jml_uuid_\".concat(INTEGRATION_ID));\n                    }\n                    catch (err) {\n                        console.warn('could not load jml unique id from local storage');\n                    }\n                    if (!uniqueId || !uniqueId.length) {\n                        uniqueId = (0,uuid__WEBPACK_IMPORTED_MODULE_1__[\"default\"])();\n                        try {\n                            localStorage.setItem(\"jml_uuid_\".concat(INTEGRATION_ID), uniqueId);\n                        }\n                        catch (err) { }\n                    }\n                    uniqueIdType = 'uuidv4';\n                    if (typeof navigator.sendBeacon === 'function') {\n                        beaconSent = navigator.sendBeacon(\"\".concat(API_BASE_URL, \"/\").concat(INTEGRATION_ID), json_stringify_safe__WEBPACK_IMPORTED_MODULE_0___default()({\n                            payload: payload,\n                            uniqueId: uniqueId,\n                            userId: userId,\n                            uniqueIdType: uniqueIdType\n                        }));\n                        if (beaconSent) {\n                            return [2 /*return*/];\n                        }\n                    }\n                    return [4 /*yield*/, fetch(\"\".concat(API_BASE_URL, \"/\").concat(INTEGRATION_ID), {\n                            method: 'POST',\n                            headers: {\n                                'Content-Type': 'application/json',\n                            },\n                            body: json_stringify_safe__WEBPACK_IMPORTED_MODULE_0___default()({\n                                payload: payload,\n                                uniqueId: uniqueId,\n                                userId: userId,\n                                uniqueIdType: uniqueIdType,\n                            }),\n                        })\n                            .catch(function (err) {\n                            console.log('gaevents message post for jewelml failed with err: ', err.message);\n                        })];\n                case 1:\n                    _a.sent();\n                    return [2 /*return*/];\n            }\n        });\n    }); };\n    var pushData = function (payload) { return __awaiter(void 0, void 0, void 0, function () {\n        var eventName, isJewelEvent, cleanPayload, generatedDataLayerEvent, isValid, key, value, queryParams, err_1;\n        return __generator(this, function (_a) {\n            switch (_a.label) {\n                case 0:\n                    _a.trys.push([0, 4, , 5]);\n                    try {\n                        if (isArgumentList(payload)) {\n                            payload = __spreadArray([], payload, true);\n                        }\n                    }\n                    catch (err) { }\n                    if (OPERATION_MODE === 'debug') {\n                        console.debug('gaevents message proxy to jewelml: ', payload);\n                    }\n                    eventName = Array.isArray(payload)\n                        ? (typeof payload[1] === 'string' ? payload[1] : '')\n                        : (typeof (payload === null || payload === void 0 ? void 0 : payload.event) === 'string' ? payload.event : '');\n                    isJewelEvent = eventName.startsWith('jewel_') || eventName.startsWith('jml_');\n                    cleanPayload = (!isJewelEvent && EXCLUDED_PAYLOAD_KEYS && Object.keys(EXCLUDED_PAYLOAD_KEYS).length)\n                        ? stripExcludedKeys(payload, EXCLUDED_PAYLOAD_KEYS)\n                        : payload;\n                    if (!DEFAULT_EVENTS[eventName]) return [3 /*break*/, 2];\n                    return [4 /*yield*/, logEvent(cleanPayload)];\n                case 1:\n                    _a.sent();\n                    return [2 /*return*/];\n                case 2:\n                    generatedDataLayerEvent = null;\n                    if (REQUIRED_EVENT_PROPERTIES && Object.keys(REQUIRED_EVENT_PROPERTIES).length) {\n                        isValid = false;\n                        for (key in REQUIRED_EVENT_PROPERTIES) {\n                            value = (0,_get_deep_value__WEBPACK_IMPORTED_MODULE_2__.getDeepValue)(payload, key);\n                            if ((REQUIRED_EVENT_PROPERTIES[key] === true && !value)\n                                || (typeof REQUIRED_EVENT_PROPERTIES[key] === 'string' && value !== REQUIRED_EVENT_PROPERTIES[key])\n                                || (Array.isArray(REQUIRED_EVENT_PROPERTIES[key]) && !REQUIRED_EVENT_PROPERTIES[key].includes(value))) {\n                                continue;\n                            }\n                            else {\n                                isValid = true;\n                                break;\n                            }\n                        }\n                        try {\n                            if (eventName !== 'jewel_pdp_view' &&\n                                (REQUIRED_EVENT_PROPERTIES === null || REQUIRED_EVENT_PROPERTIES === void 0 ? void 0 : REQUIRED_EVENT_PROPERTIES.pdp_view) &&\n                                Array.isArray(REQUIRED_EVENT_PROPERTIES.pdp_view) &&\n                                REQUIRED_EVENT_PROPERTIES.pdp_view.includes(payload.event)) {\n                                if (window.location.search.includes(\"jml_model\")) {\n                                    queryParams = new URLSearchParams(window.location.search);\n                                    generatedDataLayerEvent = {\n                                        event: \"jewel_pdp_view\",\n                                        jml_page: window.location.pathname,\n                                        jml_query: window.location.search,\n                                        original_event: cleanPayload,\n                                        jewel_model_name: queryParams.get(\"jml_model\")\n                                    };\n                                }\n                            }\n                        }\n                        catch (err) { }\n                        if (!isValid) {\n                            return [2 /*return*/, generatedDataLayerEvent];\n                        }\n                    }\n                    else if (!payload ||\n                        (!Array.isArray(payload) && !payload.ecommerce && !payload.pageCategory && payload.event !== 'homeView') ||\n                        (Array.isArray(payload) && payload[1] !== 'add_to_cart' && payload[1] !== 'purchase' && payload[1] !== 'view_item')) {\n                        return [2 /*return*/, generatedDataLayerEvent];\n                    }\n                    return [4 /*yield*/, logEvent(cleanPayload)];\n                case 3:\n                    _a.sent();\n                    return [2 /*return*/, generatedDataLayerEvent];\n                case 4:\n                    err_1 = _a.sent();\n                    try {\n                        fetch(\"\".concat(API_BASE_URL, \"/\").concat(INTEGRATION_ID, \"/error\"), {\n                            method: 'POST',\n                            headers: {\n                                'Content-Type': 'application/json',\n                            },\n                            body: JSON.stringify({\n                                error: err_1.message,\n                            }),\n                        });\n                    }\n                    catch (err) { }\n                    console.log('gaevents message post for jewelml failed with err: ', err_1.message);\n                    return [3 /*break*/, 5];\n                case 5: return [2 /*return*/];\n            }\n        });\n    }); };\n    function initProxy() {\n        if (typeof window === 'undefined')\n            return false;\n        var dataLayer = window.dataLayer;\n        if (!dataLayer || OPERATION_MODE === 'noop')\n            return false;\n        var dataLayerPush = dataLayer.push, jewelInitialized = dataLayer.jewelInitialized;\n        var jewelMLDataLayer = [];\n        var verifyAndPush = function (dataLayer, args) {\n            if (args === void 0) { args = []; }\n            dataLayer.concat(args).forEach(function (arg, index) {\n                if (!jewelMLDataLayer[index]) {\n                    pushData(arg)\n                        .then(function (generatedEvent) {\n                        if (!generatedEvent)\n                            return;\n                        pushData(generatedEvent);\n                        try {\n                            var previousLength = dataLayer.length;\n                            var pushResult = dataLayerPush.apply(dataLayer, [generatedEvent]);\n                            var generatedIndex = typeof pushResult === 'number'\n                                ? pushResult - 1\n                                : dataLayer.indexOf(generatedEvent, previousLength);\n                            if (generatedIndex >= 0) {\n                                jewelMLDataLayer[generatedIndex] = generatedEvent;\n                            }\n                        }\n                        catch (err) { }\n                    });\n                }\n                jewelMLDataLayer[index] = arg;\n            });\n        };\n        if (jewelInitialized)\n            return true;\n        dataLayer.jewelInitialized = true;\n        dataLayer.push = function () {\n            var args = [];\n            for (var _i = 0; _i < arguments.length; _i++) {\n                args[_i] = arguments[_i];\n            }\n            try {\n                if (OPERATION_MODE === 'debug') {\n                    console.debug('gaevents dataLayer proxy triggered');\n                }\n                verifyAndPush(dataLayer, args);\n                if (OPERATION_MODE === 'debug') {\n                    console.debug('gaevents passing through dataLayer arguments', args);\n                }\n            }\n            catch (err) {\n                console.log('gaevents failed with err: ', err.message);\n            }\n            return dataLayerPush.apply(dataLayer, args);\n        };\n        if (dataLayer.length) {\n            verifyAndPush(dataLayer, []);\n        }\n        return true;\n    }\n    if (!initProxy()) {\n        var attempts_1 = 0;\n        var poll_1 = setInterval(function () {\n            if (initProxy() || ++attempts_1 >= 10)\n                clearInterval(poll_1);\n        }, 1000);\n    }\n})();\n\n\n//# sourceURL=webpack://ga4events.jewelml.io/./client/index.ts?\n}");

/***/ },

/***/ "./node_modules/uuid/dist/esm-browser/native.js"
/*!******************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/native.js ***!
  \******************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\nconst randomUUID = typeof crypto !== 'undefined' && crypto.randomUUID && crypto.randomUUID.bind(crypto);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({\n  randomUUID\n});\n\n//# sourceURL=webpack://ga4events.jewelml.io/./node_modules/uuid/dist/esm-browser/native.js?\n}");

/***/ },

/***/ "./node_modules/uuid/dist/esm-browser/regex.js"
/*!*****************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/regex.js ***!
  \*****************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i);\n\n//# sourceURL=webpack://ga4events.jewelml.io/./node_modules/uuid/dist/esm-browser/regex.js?\n}");

/***/ },

/***/ "./node_modules/uuid/dist/esm-browser/rng.js"
/*!***************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/rng.js ***!
  \***************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ rng)\n/* harmony export */ });\n// Unique ID creation requires a high quality random # generator. In the browser we therefore\n// require the crypto API and do not support built-in fallback to lower quality random number\n// generators (like Math.random()).\nlet getRandomValues;\nconst rnds8 = new Uint8Array(16);\nfunction rng() {\n  // lazy load so that environments that need to polyfill have a chance to do so\n  if (!getRandomValues) {\n    // getRandomValues needs to be invoked in a context where \"this\" is a Crypto implementation.\n    getRandomValues = typeof crypto !== 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto);\n\n    if (!getRandomValues) {\n      throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');\n    }\n  }\n\n  return getRandomValues(rnds8);\n}\n\n//# sourceURL=webpack://ga4events.jewelml.io/./node_modules/uuid/dist/esm-browser/rng.js?\n}");

/***/ },

/***/ "./node_modules/uuid/dist/esm-browser/stringify.js"
/*!*********************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/stringify.js ***!
  \*********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   unsafeStringify: () => (/* binding */ unsafeStringify)\n/* harmony export */ });\n/* harmony import */ var _validate_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./validate.js */ \"./node_modules/uuid/dist/esm-browser/validate.js\");\n\n/**\n * Convert array of 16 byte values to UUID string format of the form:\n * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX\n */\n\nconst byteToHex = [];\n\nfor (let i = 0; i < 256; ++i) {\n  byteToHex.push((i + 0x100).toString(16).slice(1));\n}\n\nfunction unsafeStringify(arr, offset = 0) {\n  // Note: Be careful editing this code!  It's been tuned for performance\n  // and works in ways you may not expect. See https://github.com/uuidjs/uuid/pull/434\n  return byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + '-' + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + '-' + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + '-' + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + '-' + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]];\n}\n\nfunction stringify(arr, offset = 0) {\n  const uuid = unsafeStringify(arr, offset); // Consistency check for valid UUID.  If this throws, it's likely due to one\n  // of the following:\n  // - One or more input array values don't map to a hex octet (leading to\n  // \"undefined\" in the uuid)\n  // - Invalid input values for the RFC `version` or `variant` fields\n\n  if (!(0,_validate_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"])(uuid)) {\n    throw TypeError('Stringified UUID is invalid');\n  }\n\n  return uuid;\n}\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (stringify);\n\n//# sourceURL=webpack://ga4events.jewelml.io/./node_modules/uuid/dist/esm-browser/stringify.js?\n}");

/***/ },

/***/ "./node_modules/uuid/dist/esm-browser/v4.js"
/*!**************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/v4.js ***!
  \**************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _native_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./native.js */ \"./node_modules/uuid/dist/esm-browser/native.js\");\n/* harmony import */ var _rng_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rng.js */ \"./node_modules/uuid/dist/esm-browser/rng.js\");\n/* harmony import */ var _stringify_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./stringify.js */ \"./node_modules/uuid/dist/esm-browser/stringify.js\");\n\n\n\n\nfunction v4(options, buf, offset) {\n  if (_native_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"].randomUUID && !buf && !options) {\n    return _native_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"].randomUUID();\n  }\n\n  options = options || {};\n  const rnds = options.random || (options.rng || _rng_js__WEBPACK_IMPORTED_MODULE_1__[\"default\"])(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`\n\n  rnds[6] = rnds[6] & 0x0f | 0x40;\n  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided\n\n  if (buf) {\n    offset = offset || 0;\n\n    for (let i = 0; i < 16; ++i) {\n      buf[offset + i] = rnds[i];\n    }\n\n    return buf;\n  }\n\n  return (0,_stringify_js__WEBPACK_IMPORTED_MODULE_2__.unsafeStringify)(rnds);\n}\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (v4);\n\n//# sourceURL=webpack://ga4events.jewelml.io/./node_modules/uuid/dist/esm-browser/v4.js?\n}");

/***/ },

/***/ "./node_modules/uuid/dist/esm-browser/validate.js"
/*!********************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/validate.js ***!
  \********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _regex_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./regex.js */ \"./node_modules/uuid/dist/esm-browser/regex.js\");\n\n\nfunction validate(uuid) {\n  return typeof uuid === 'string' && _regex_js__WEBPACK_IMPORTED_MODULE_0__[\"default\"].test(uuid);\n}\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (validate);\n\n//# sourceURL=webpack://ga4events.jewelml.io/./node_modules/uuid/dist/esm-browser/validate.js?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	const __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		const cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		const module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		if (!(moduleId in __webpack_modules__)) {
/******/ 			delete __webpack_module_cache__[moduleId];
/******/ 			const e = new Error("Cannot find module '" + moduleId + "'");
/******/ 			e.code = 'MODULE_NOT_FOUND';
/******/ 			throw e;
/******/ 		}
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			const getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter/value functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			if(Array.isArray(definition)) {
/******/ 				var i = 0;
/******/ 				while(i < definition.length) {
/******/ 					var key = definition[i++];
/******/ 					var binding = definition[i++];
/******/ 					if(!__webpack_require__.o(exports, key)) {
/******/ 						if(binding === 0) {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, value: definition[i++] });
/******/ 						} else {
/******/ 							Object.defineProperty(exports, key, { enumerable: true, get: binding });
/******/ 						}
/******/ 					} else if(binding === 0) { i++; }
/******/ 				}
/******/ 			} else {
/******/ 				for(var key in definition) {
/******/ 					if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 						Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	let __webpack_exports__ = __webpack_require__("./client/index.ts");
/******/ 	
/******/ })()
;