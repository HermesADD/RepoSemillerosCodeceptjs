(function(){var K=document.head||document.getElementsByTagName("head")[0];if(!document.querySelector("link[data-jml-swiper-css]")){var Y=document.createElement("link");Y.rel="stylesheet",Y.href="https://cdn.jsdelivr.net/npm/swiper@11.0.5/swiper-bundle.min.css",Y.setAttribute("data-jml-swiper-css","1"),Y.onerror=function(){var H=document.createElement("link");H.rel="stylesheet",H.href="https://rerender.jewelml.io/lib/swiper-bundle.min.css",H.setAttribute("data-jml-swiper-css","fallback"),K.appendChild(H)},K.appendChild(Y)}function re(){"2.3.8";window.jml=window.jml||{},Object.assign(window.jml,window.jmlrc||{});try{window.jml.item_id=(()=>{function _(S){return S!=null&&(S=S.toLowerCase(),S=S.normalize("NFKD"),S=S.replace(/[\u0300-\u036f]/g,""),S=S.replace(/\s+/g,"_")),S}function R(){function S(){const j=window.__next_f.filter(d=>Array.isArray(d)&&d[0]===1&&typeof d[1]=="string").map(d=>d[1]);for(const d of document.querySelectorAll("script")){let y,g=/__next_f\.push\(\[(\d+),(.*)\]\s*\)/gs;for(;(y=g.exec(d.textContent))!==null;)if(parseInt(y[1])===1)try{const k=JSON.parse(y[2]);typeof k=="string"&&j.push(k)}catch{}}const M=j.join(""),D=new Map;let C=0;for(;C<M.length;){const d=M.indexOf(":",C);if(d===-1)break;const y=M.substring(C,d);if(!/^[0-9a-f]+$/i.test(y)){const k=M.indexOf(`
`,C);C=k<0?M.length:k+1;continue}const g=M.indexOf(`
`,d+1);D.set(y,g<0?M.substring(d+1):M.substring(d+1,g)),C=g<0?M.length:g+1}const b=new Map,c=new Set(["{","[",'"',"'","-","0","1","2","3","4","5","6","7","8","9","t","f","n"]);for(const[d,y]of D)try{b.set(d,c.has(y[0])?JSON.parse(y):y)}catch{b.set(d,y)}function x(d){return d&&typeof d=="object"&&!Array.isArray(d)&&typeof d.maximumListPrice=="number"&&typeof d.minimumPromoPrice=="number"&&Array.isArray(d.sizeSet)&&Array.isArray(d.variants)&&d.variants.length>0&&d.variants[0]!==null&&Array.isArray(d.colorSet)}function v(d,y=new WeakSet,g=0){if(g>80||d==null)return null;if(typeof d=="string"){if(d.startsWith("$")&&!d.startsWith("$L")){const k=b.get(d.slice(1));if(k!=null)return v(k,y,g+1)}return null}if(typeof d!="object"||y.has(d))return null;if(y.add(d),x(d))return d;for(const k of Array.isArray(d)?d:Object.values(d)){const $=v(k,y,g+1);if($)return $}return null}const N=v(b.get("c"));if(!N)return null;const Q=new URLSearchParams(window.location.search).get("skuid"),h=N.variants.map(d=>({skuId:d.skuId,colorName:d.colorName??null}));return{id:N.id,hasColor:N.colorSet.length>0,selectedVariant:h.find(d=>d.skuId===Q)??h[0]??null}}function P(){const j=document.querySelector("h1");if(!j)return null;const M=Object.keys(j).find(C=>C.startsWith("__reactFiber"));if(!M)return null;let D=j[M];for(;D;){const C=D.memoizedProps;if(C&&C.product&&typeof C.product.id<"u"){const b=C.product,c=new URLSearchParams(window.location.search).get("skuid"),x=(b.variants||[]).filter(v=>v).map(v=>({skuId:v.skuId,colorName:v.colorName??null}));return{id:b.id,hasColor:Array.isArray(b.colorSet)&&b.colorSet.length>0,selectedVariant:x.find(v=>v.skuId===c)??x[0]??null}}D=D.return}return null}const F=window.location.pathname.split("/").filter(Boolean).pop(),A=S();if(A&&A.id===F)return A;const L=P();if(L)return L;if(A)return A;throw new Error("Product not found")}function O(S,P){if(!S)return{color:void 0,productId:void 0};const F=S?.variants,A=F.findIndex(M=>M.clothingBrandColor?_(M.clothingBrandColor)===_(P):_(M.color)===_(P)),L=A<0?0:A;return F[L]?.color}function U(){let S;return document.querySelector(".attributeAccordionText")?.innerText.includes("Color")&&(S=document.querySelector(".attributeAccordionTextValue")?.textContent?.trim()),{elementColor:S}}function q(){jml.logs=jml.logs??[];const{elementColor:S}=U();if(!S)return;if(window.next.router.components["/tienda/oneColumnPage"].props.pageProps.initialPropsData)return O(window.next.router.components["/tienda/oneColumnPage"].props.pageProps.initialPropsData.mainContent.records[0].allMeta,S);const P=JSON.parse(document.querySelector("#__NEXT_DATA__")?.innerText);return O(P.query?.data?.mainContent?.records?.at(0)?.allMeta,S)}try{if(window?.jml?.isStaging){const F=R();if(!F)return"empty";if(F.hasColor){const A=_(F.selectedVariant.colorName);return`${F.id}_${A}`}return F.id}let S=window.location.pathname.split("/").pop();if(!S)return"empty";let P=q();return P?(P=_(P),`${S}_${P}`):S}catch{return"empty"}})()||"empty"}catch(_){jml.debug().log("failed to load __jml_item_id",_),window.jml.item_id="empty"}window.location.search.includes("dev=jewel")?(console.log("dev=jewel detected, loading dev_custom_selector_function"),window.location.search.includes("dev=jewel")&&(window.__jml_custom_function=(()=>{window.jml.isStaging=!0;const _="LP";window.jml.userIsLoggedIn=!1;const R="jml-hide-add-to-cart";function O(){if(document.getElementById(R))return;const t=document.createElement("style");t.id=R,t.textContent=`
      ._jml_carousel_slide .jml-add-to-cart-wrapper {
        display: none !important;
      }
      ._jml_carousel_slide:hover .jml-add-to-cart-wrapper {
        display: none !important;
      }
      ._jml_carousel_slide._jml_carousel_slide:hover .jml-add-to-cart-wrapper.jml-add-to-cart-wrapper {
          display: none !important;
      }

      [id^="jml-mobileAddtoCart-button-wrapper-"] {
        display: none !important;
      }
    `,document.head.appendChild(t)}function U(){const t=document.getElementById(R);t&&t.remove()}function q(t,n){const e=new Date;e.setFullYear(e.getFullYear()+1),document.cookie=[t+"="+encodeURIComponent(n),"path=/","expires="+e.toUTCString(),"SameSite=Lax"].join("; ")}function S(t){document.cookie=`${t}=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax`}jml.checkAuthState=()=>{O();function t(i){const s=document.cookie.match(new RegExp("(^| )"+i+"=([^;]+)"));return s?s[2]:null}if(t("x-cs-folio-id"))return;const e=`jml_userid_${jml.integration_id}`,o=localStorage.getItem("jewel_hashed_userid");o&&o!==" "&&o!=="null"&&o!=="undefined"&&o!=="na"?(window.jml.userIsLoggedIn=!0,localStorage.setItem(e,o),window.jml.wishlistUpdate(),U()):(window.jml.userIsLoggedIn=!1,localStorage.removeItem(e),S(e))};let P=null;jml.oldCheckAuthState=()=>{P&&clearInterval(P),P=setInterval(()=>{if(!window.getProfileId||!window.getProfileId())return;const t=window.getProfileId();if(!t||t===""||t==="undefined"||t==="null"){window.jml.userIsLoggedIn=!1;const n=`jml_userid_${jml.integration_id}`;localStorage.removeItem(n),S(n)}else window.jml.userIsLoggedIn=!0,window.jml.wishlistUpdate();clearInterval(P)},100)};async function F(t){const n=new TextEncoder,e=await crypto.subtle.importKey("raw",n.encode("jewelml"),{name:"HMAC",hash:"SHA-256"},!1,["sign"]),o=await crypto.subtle.sign("HMAC",e,n.encode(t));return Array.from(new Uint8Array(o)).map(i=>i.toString(16).padStart(2,"0")).join("")}const A=function(){const t=localStorage.setItem.bind(localStorage),n=localStorage.removeItem.bind(localStorage),e=localStorage.clear.bind(localStorage);localStorage.setItem=function(o,i){const s=localStorage.getItem(o);t(o,i),window.dispatchEvent(new CustomEvent("jml:ls-change",{detail:{type:"set",key:o,value:i,oldValue:s}}))},localStorage.removeItem=function(o){const i=localStorage.getItem(o);n(o),window.dispatchEvent(new CustomEvent("jml:ls-change",{detail:{type:"remove",key:o,oldValue:i}}))},localStorage.clear=function(){e(),window.dispatchEvent(new CustomEvent("jml:ls-change",{detail:{type:"clear"}}))},window.addEventListener("jml:ls-change",({detail:{key:o,type:i,value:s}})=>{o&&((o.startsWith("jml_userid_")||o.startsWith("jml_uuid_"))&&i==="set"&&q(o,s),o==="jewel_hashed_userid"&&setTimeout(()=>jml.checkAuthState()))}),setTimeout(()=>{const o=i=>{const s=localStorage.getItem(i);s&&q(i,s)};o(`jml_uuid_${jml.integration_id}`),o(`jml_userid_${jml.integration_id}`);try{if(!localStorage.getItem(`jml_uuid_${window.jml.integration_id}`)){const s=crypto.randomUUID();localStorage.setItem(`jml_uuid_${window.jml.integration_id}`,s)}}catch{}})};localStorage?A():setTimeout(()=>A()),window.jml.sendJewelViewItem=t=>{window.location.pathname.startsWith("/tienda/pdp/")&&t!=="empty"&&window.dataLayer.push({event:"jewel_view_item",item_id:t})},setTimeout(()=>{try{const n=localStorage.getItem("jml_userid_67fd95260740ccc4ec658d03");["7ffff06e660184dcf111c63dab65561abba1bff7ca050cae8bc0e8c392398092"].includes(n)&&localStorage.removeItem("jml_userid_67fd95260740ccc4ec658d03")}catch{}window.jml.personalizedSavedModels=[...window.jml.personalizedSavedModels,"recently-viewed-items-global","recently-viewed-items-global-dev"];let t=window.jml.item_id;window.jml.sendJewelViewItem(t),Object.defineProperty(window.jml,"item_id",{configurable:!0,enumerable:!0,get(){return t},set(n){const e=t;t=n,n!==e&&window.dispatchEvent(new CustomEvent("jml:item_id_changed",{bubbles:!0,detail:{oldValue:e,newValue:n,timestamp:Date.now()}}))}}),window.addEventListener("jml:item_id_changed",function(n){const{newValue:e}=n.detail;window.jml.sendJewelViewItem(e)}),window.jml.isStaging=isGcpMigrated(),window.jml.integration_id&&(window.jml.isStaging?jml.checkAuthState():jml.oldCheckAuthState())});const L=document.createElement("style");L.type="text/css",L.textContent=`
  .o-carousel-section {
      display: none !important;
  }
  .wishlist-snackbar {
      z-index: 9999999999 !important;
  }
  `,window.jml.isStaging&&(L.textContent+=`
      section[data-testid*="container-similar-products-grid"] {
        padding-top: 0px !important;
      }
      section[data-testid*="container-similar-products-grid"] > div:not([id]) {
        display: none;
      }

      div[id*="jml-carousel"] {
        margin-top: 32px !important;
      }
    `),L.textContent+=`
    @keyframes jml-spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    @keyframes jml-skeleton-shimmer {
      0% { background-position: -240px 0; }
      100% { background-position: calc(240px + 100%) 0; }
    }
    .jml-skeleton {
      background-color: #efefef;
      background-image: linear-gradient(90deg, #efefef 0%, #e4e4e4 50%, #efefef 100%);
      background-size: 240px 100%;
      background-repeat: no-repeat;
      animation: jml-skeleton-shimmer 1.4s ease-in-out infinite;
      border-radius: 4px;
      display: inline-block;
    }
    .jewel-modal-confirm-button[disabled] {
      opacity: 0.5;
      cursor: not-allowed;
    }
  `,document.head.appendChild(L);const j="url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNyIgaGVpZ2h0PSIxNyIgdmlld0JveD0iMCAwIDE3IDE3IiBmaWxsPSJub25lIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0yLjE0NTUxIDUuOTM3OUMyLjE0NTUxIDMuODA4MzkgMy44NDgxNCAyLjE0MDg3IDUuOTg0MjEgMi4xNDA4N0M2LjkzOTk4IDIuMTQwODcgNy44NjAxMSAyLjQ4Nzk0IDguNTc1MDkgMy4wNjgzMUM5LjI5MDA2IDIuNDg3OTQgMTAuMjEwMiAyLjE0MDg3IDExLjE2NiAyLjE0MDg3QzEzLjMwMiAyLjE0MDg3IDE1LjAwNDcgMy44MDgzOSAxNS4wMDQ3IDUuOTM3OUMxNS4wMDQ3IDcuMjM1NDQgMTQuNDA3MiA4LjM1ODg0IDEzLjUwMDggOS40NTMyMkMxMi42MTMxIDEwLjUyNDkgMTEuMzU5NSAxMS42NDkxIDkuOTE0MTcgMTIuOTQ1Mkw5Ljg1ODYzIDEyLjk5NUw5Ljg1NzE4IDEyLjk5NjNMOC41NzMzOCAxNC4xNDA5TDcuMjkxMTEgMTIuOTg4OUw3LjI1MDc5IDEyLjk1MjhDNS43OTkzIDExLjY1NCA0LjU0MDI3IDEwLjUyNzMgMy42NDk1NSA5LjQ1MjY4QzIuNzQyOTcgOC4zNTg4OCAyLjE0NTUxIDcuMjM1NDUgMi4xNDU1MSA1LjkzNzlaIiBmaWxsPSIjZTEwMDk4Ii8+Cjwvc3ZnPg==')",M="url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNyIgaGVpZ2h0PSIxNyIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIj48Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSI5IiBzdHJva2U9IiNlMTAwOTgiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtZGFzaGFycmF5PSI0MiAxNCIvPjwvc3ZnPg==')",D="url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTciIHZpZXdCb3g9IjAgMCAxNiAxNyIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik01LjE3MjA4IDMuNTA0MThDMy43NjE1MiAzLjUwNDE4IDIuNjc3NTIgNC41ODY2MyAyLjY3NzUyIDUuOTU3MDdDMi42Nzc1MiA2LjgwNzIzIDMuMDU4ODQgNy42MzI2NCAzLjg3MjMxIDguNjE0MDlDNC42OTMyMSA5LjYwNDUxIDUuODgwMDcgMTAuNjY4NCA3LjM3NjI5IDEyLjAwNzNMNy4zNzcyNiAxMi4wMDgyTDcuNzY0NjYgMTIuMzU2Mkw4LjE0OTA5IDEyLjAxMzVDOC4xNDkzMyAxMi4wMTMyIDguMTQ5NTYgMTIuMDEzIDguMTQ5OCAxMi4wMTI4QzkuNjQ1ODQgMTAuNjcxMiAxMC44MzI1IDkuNjA2MTEgMTEuNjUzNSA4LjYxNDk3QzEyLjQ2NzEgNy42MzI2OCAxMi44NDg0IDYuODA3MjQgMTIuODQ4NCA1Ljk1NzA3QzEyLjg0ODQgNC41ODY2MyAxMS43NjQ0IDMuNTA0MTggMTAuMzUzOCAzLjUwNDE4QzkuNTUyMjIgMy41MDQxOCA4Ljc3NDgzIDMuODc1NyA4LjI3MTc4IDQuNDU4NjdMNy43NjI5NSA1LjA0ODMyTDcuMjU0MTMgNC40NTg2N0M2Ljc1MTA4IDMuODc1NyA1Ljk3MzY5IDMuNTA0MTggNS4xNzIwOCAzLjUwNDE4Wk0xLjMzMzM3IDUuOTU3MDdDMS4zMzMzNyAzLjgyNzU1IDMuMDM2MDEgMi4xNjAwMyA1LjE3MjA4IDIuMTYwMDNDNi4xMjc4NSAyLjE2MDAzIDcuMDQ3OTggMi41MDcxMSA3Ljc2Mjk1IDMuMDg3NDhDOC40Nzc5MyAyLjUwNzExIDkuMzk4MDYgMi4xNjAwMyAxMC4zNTM4IDIuMTYwMDNDMTIuNDg5OSAyLjE2MDAzIDE0LjE5MjUgMy44Mjc1NSAxNC4xOTI1IDUuOTU3MDdDMTQuMTkyNSA3LjI1NDYgMTMuNTk1MSA4LjM3OCAxMi42ODg2IDkuNDcyMzhDMTEuODAxIDEwLjU0NDEgMTAuNTQ3NCAxMS42NjgzIDkuMTAyMDMgMTIuOTY0NEw5LjA0NjQ5IDEzLjAxNDJMOS4wNDUwNCAxMy4wMTU1TDcuNzYxMjUgMTQuMTZMNi40Nzg5NyAxMy4wMDgxTDYuNDM4NjUgMTIuOTcyQzQuOTg3MTcgMTEuNjczMSAzLjcyODE0IDEwLjU0NjUgMi44Mzc0MiA5LjQ3MTg1QzEuOTMwODMgOC4zNzgwNCAxLjMzMzM3IDcuMjU0NjEgMS4zMzMzNyA1Ljk1NzA3WiIgZmlsbD0iIzVDNUM1QyIvPgo8L3N2Zz4K')",C={"x-brand-id":_,"Content-Type":"application/json"};window.jml.getProductById=async t=>await(await fetch(`/web-bff/product/${t}`,{headers:C})).json(),window.jml.redirects=(t,n)=>{if(window.jml.isStaging){let u=function(f){const m=document.querySelector(`[offer-id="${f}"]`);return m?m.closest("._jml_card_wrapper")?.querySelector("[data-variant]")?.getAttribute("data-variant")??null:null};var a=u;if(!(n.split("_").length>1)){window.next.router.push(t);return}const p=u(n);window.next.router.push(`${t}&skuid=${p}`);return}const e=t.match(/\/tienda\/pdp\/([^\/]+(?:\/[^\/]+)*)\/(\d+)/);if(!e)return;const o=e[1],i=t.split("/").at(-1).split("?")[0],l=`/tienda/oneColumnPage?productName=${o.split("-").map(w=>w.charAt(0).toUpperCase()+w.slice(1)).join("-")}&productId=${i}&pdpTypeForSPA=default&skuId=${n||i}`,r=`${t}${t.includes("?")?"&":"?"}skuid=${n.split("_")[0]||i}`;window.next.router.push(l,r,{scroll:!1}),window.scrollTo({top:0,behavior:"smooth"})},window.jml.updateTPSTitle=jml.debounce(async function(){const t=document.querySelector('[data-jmlmodel="T_prod"]');if(!t)return;let n=t.closest('[id$="-jml-carousel"]');if(!n)return;const e=n.querySelector("._jml_section_title_css");if(!e)return;let o=null;try{const i=[],s=window.jml.isStaging?'[data-testid$="-breadcrumb-ul"]':".m-breadcrumb-list";if(document.querySelector(s)?.childNodes?.forEach(l=>{i.push(l.innerText)}),i.length>1)o=i.at(-1).trim().toLowerCase();else{const l=window.location.pathname.split("/").at(-1);if(window.jml.isStaging){const{categoryBreadCrumbs:r}=await window.jml.getProductById(l);o=r.at(-1).categoryName.trim().toLowerCase()}else{const r=await fetch("/getpdpdynamiccontent",{method:"POST",body:JSON.stringify({productId:l})});r.ok&&(o=(await r.json()).breadCrumbs.at(-1).categoryName.trim().toLowerCase())}}}catch{}o&&(e.textContent=`Los m\xE1s vendidos en ${o}`)},50),window.jml.getProductData=async(t,n)=>{const e=await fetch(`/tienda/oneColumnPageData?productId=${t}&pdpType=default&skuId=${n}`,{method:"GET",credentials:"include",headers:{"content-type":"application/json",accept:"application/json",brand:_,channel:"WEB"}});return e.ok?await e.json():null},window.jml.showSnackbar=(t,n="success",e=3e3)=>{const o=document.querySelectorAll(".mdc-snackbar");o.forEach((a,w)=>{a.style.margin="6px",a.setAttribute("data-debug-index",w)});const i=o[n==="success"?1:n==="warning"?2:0],s=document.querySelectorAll(".m-alert__container.mdc-snackbar")[1],l=document.querySelectorAll(".a-alert__icon")[1],r=i.querySelector(".mdc-snackbar__label");r&&(r.textContent=t),s.classList.contains("-alert")&&s.classList.remove("-alert"),l.classList.contains("icon-error")&&(l.classList.remove("icon-error"),l.classList.add("icon-done")),s.classList.add("-success"),i.classList.add("mdc-snackbar--open"),i.offsetWidth,setTimeout(()=>{i.classList.remove("mdc-snackbar--open"),l.classList.add("icon-error"),l.classList.remove("icon-done")},e)},window.jml.showAlertSnackbar=(t,n=3e3)=>{const e=document.querySelector(".m-alert__container.mdc-snackbar.-alert")||document.querySelector(".m-alert__container.mdc-snackbar");if(!e)return;e.classList.add("-alert"),e.classList.remove("-success");const o=e.querySelector(".a-alert__icon");o&&(o.classList.add("icon-error"),o.classList.remove("icon-done"));const i=e.querySelector(".mdc-snackbar__label");i&&(i.textContent=t),e.classList.add("mdc-snackbar--open"),e.offsetWidth,setTimeout(()=>{e.classList.remove("mdc-snackbar--open")},n)},window.jml.showSuccessSnackbar=(t,n=3e3)=>{const e=document.querySelector(".m-alert__container.mdc-snackbar.-success")||document.querySelector(".m-alert__container.mdc-snackbar");if(!e)return;e.classList.add("-success"),e.classList.remove("-alert");const o=e.querySelector(".a-alert__icon");o&&(o.classList.add("icon-done"),o.classList.remove("icon-error"));const i=e.querySelector(".mdc-snackbar__label");i&&(i.textContent=t),e.classList.add("mdc-snackbar--open"),e.offsetWidth,setTimeout(()=>{e.classList.remove("mdc-snackbar--open")},n)};const b=(()=>{const t={success:{bg:"rgb(231, 248, 236)",color:"rgb(7, 134, 44)",icon:"check_circle_outline"},error:{bg:"rgb(255, 230, 230)",color:"rgb(181, 0, 0)",icon:"error_outline"},warning:{bg:"rgb(253, 245, 230)",color:"rgb(168, 112, 0)",icon:"warning_amber"},info:{bg:"rgb(235, 247, 249)",color:"rgb(39, 121, 141)",icon:"info_outline"}};function n(){if(document.getElementById("jewel-toast-styles"))return;const l=document.createElement("style");l.id="jewel-toast-styles",l.textContent=`
        #jewel-toast-root {
          position: fixed;
          top: 128px;
          left: 0;
          right: 0;
          z-index: 99999999;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          padding: 0px 16px 12px 16px;
          pointer-events: none;
          box-sizing: border-box;
        }

        /* Desktop: respect the navbar height (128px) + extra breathing room */
        @media (min-width: 768px) {
          #jewel-toast-root {
            padding: 0;
          }
        }

        .jewel-toast {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          width: 100%;
          max-width: 688px;
          padding: 13px 12px;
          border-radius: 4px;
          box-shadow: rgba(20, 20, 20, 0.12) 0px 6px 12px 0px;
          font-family: Gotham-Medium, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          font-size: 12px;
          font-weight: 500;
          line-height: 1.4;
          box-sizing: border-box;
          pointer-events: all;
          height: 48px;

          /* Entrance animation */
          opacity: 0;
          transform: translateY(-10px);
          transition: opacity 220ms ease, transform 220ms ease;
        }

        /* On mobile: full width with horizontal margins handled by root padding */
        @media (max-width: 767px) {
          .jewel-toast {
            max-width: 100%;
            font-size: 12px;
            padding: 14px 14px;
          }
        }

        .jewel-toast.jewel-toast--visible {
          opacity: 1;
          transform: translateY(0);
        }

        .jewel-toast--exit {
          opacity: 0 !important;
          transform: translateY(-10px) !important;
        }

        .jewel-toast__body {
          display: flex;
          align-items: center;
          gap: 8px;
          flex: 1;
          min-width: 0;
        }

        .jewel-toast__icon {
          font-family: 'Material Icons';
          font-size: 16px;
          font-style: normal;
          font-weight: normal;
          line-height: 1;
          flex-shrink: 0;
          user-select: none;
        }

        .jewel-toast__message {
          flex: 1;
          min-width: 0;
          word-break: break-word;
        }

        .jewel-toast__close {
          background: none;
          border: none;
          padding: 0;
          margin: 0;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          opacity: 0.7;
          transition: opacity 150ms ease;
          line-height: 1;
        }

        .jewel-toast__close:hover {
          opacity: 1;
        }

        .jewel-toast__close-icon {
          font-family: 'Material Icons';
          font-size: 16px;
          font-style: normal;
          font-weight: normal;
          line-height: 1;
          user-select: none;
        }
      `,document.head.appendChild(l)}function e(){let l=document.getElementById("jewel-toast-root");return l||(l=document.createElement("div"),l.id="jewel-toast-root",l.setAttribute("role","region"),l.setAttribute("aria-live","polite"),l.setAttribute("aria-label","Notifications"),document.body.appendChild(l)),l}function o(l,r){const a=t[l]||t.info,w="jt-"+Date.now()+"-"+Math.random().toString(36).slice(2,6),u=document.createElement("div");u.id=w,u.className="jewel-toast",u.setAttribute("role","alert"),u.style.backgroundColor=a.bg,u.style.color=a.color;const p=document.createElement("div");p.className="jewel-toast__body";const f=document.createElement("span");f.className="jewel-toast__icon",f.textContent=a.icon,f.style.color=a.color,f.setAttribute("aria-hidden","true");const m=document.createElement("span");m.className="jewel-toast__message",m.textContent=r,p.appendChild(f),p.appendChild(m);const I=document.createElement("button");I.className="jewel-toast__close",I.setAttribute("aria-label","Cerrar notificaci\xF3n"),I.style.color=a.color;const B=document.createElement("span");return B.className="jewel-toast__close-icon",B.textContent="close",B.setAttribute("aria-hidden","true"),I.appendChild(B),u.appendChild(p),u.appendChild(I),{toast:u,id:w,closeBtn:I}}function i(l){const r=document.getElementById(l);r&&(r.classList.add("jewel-toast--exit"),setTimeout(()=>{r.remove();const a=document.getElementById("jewel-toast-root");a&&a.children.length===0&&a.remove()},220))}function s(l,r,a=4e3){n();const w=e(),{toast:u,id:p,closeBtn:f}=o(l,r);w.appendChild(u),requestAnimationFrame(()=>{requestAnimationFrame(()=>{u.classList.add("jewel-toast--visible")})});let m=setTimeout(()=>i(p),a);return u.addEventListener("mouseenter",()=>clearTimeout(m)),u.addEventListener("mouseleave",()=>{m=setTimeout(()=>i(p),1500)}),f.addEventListener("click",()=>{clearTimeout(m),i(p)}),p}return{success:(l,r)=>s("success",l,r),error:(l,r)=>s("error",l,r),warning:(l,r)=>s("warning",l,r),info:(l,r)=>s("info",l,r),dismiss:i}})();function c(){const t=document.querySelector('[data-testid="product-configurator-delivery-selection-card-Recibe a domicilio"]'),n=document.querySelector('[data-testid="product-configurator-delivery-selection-card-Click & Collect"]');if(!t||!n)return null;const e=o=>o.querySelector("span.material-icons")!==null;return e(t)?"home":e(n)?"click-collect":null}async function x(){try{return(await(await fetch(`${BFF}/user/favoriteStore`,{headers:C})).json()).id}catch{return}}async function v(t,n){try{const{variants:e}=await window.jml.getProductById(t),o=e.find(i=>i.skuId===n)?.offers?.bestOffer;return o?{offerId:o.offerId,sellerId:o.sellerId}:void 0}catch{return}}async function N(t,{retryableCodes:n=new Set,successCodes:e=new Set,maxRetries:o=1}={}){for(let i=0;i<=o;i++){const s=await t();if(s.ok)return{status:"success",data:await s.json().catch(()=>null)};const l=await s.json().catch(()=>({}));if(e.has(l.code))return{status:"success"};if(!(n.has(l.code)&&i<o))return{status:"fail",error:l}}}function Q(t){return t!=null&&(t=t.toLowerCase(),t=t.normalize("NFKD"),t=t.replace(/[\u0300-\u036f]/g,""),t=t.replace(/\s+/g,"_")),t}window.jml.wishlistUpdate=jml.debounce(async function(){if(!window.jml.userIsLoggedIn)return;function t(o){const i=document.cookie.match(new RegExp("(^| )"+o+"=([^;]+)"));return i?i[2]:null}if(t("x-cs-folio-id"))return;document.querySelectorAll('[id^="jml-wishlist-button-wrapper"]').forEach(o=>{o.style.display="block"});try{if(window.jml.isStaging){const i=await(await fetch("/web-bff/wishlists/details",{credentials:"include",headers:C})).json();if(i.length===0)return;let s=i.find(({wishlist:l})=>l.isDefault);s||(s=i[0]),window.jml.wishlistId=s.wishlist.id,window.jml.wishlistName=s.wishlist.name,s.items?.forEach(({id:l,wishlistItemId:r})=>{const a=`[id^="jml-wishlist-button-wrapper-${l}"]`;document.querySelectorAll(a).forEach(w=>{w.style.backgroundImage=j,w.classList.add("jewel_added_wishlist"),w.dataset.wishlistItemId=r})})}else{const s=(await(await fetch("/wishListSimpleApigee",{credentials:"include",headers:{accept:"application/json",brand:_,channel:"WEB"}})).json())?.lstWishList;if(!s)return;let l=s.find(({isDefault:r})=>r);l||(l=s[0]),window.jml.wishlistId=l.id,window.jml.wishlistName=l.name,l.lstWishListDetails?.forEach(r=>{const w=`[id^="jml-wishlist-button-wrapper-${r.productId}"]`;document.querySelectorAll(w).forEach(u=>{u.style.backgroundImage=j,u.classList.add("jewel_added_wishlist"),u.dataset.wishlistItemId=r.wishlistProdId})})}}catch{}},250),window.jml.wishlistUpdateUI=(t,n,e)=>{const o=n.split("_")[0],i=document.querySelectorAll(`[id^="jml-wishlist-button-wrapper-${o}"]`),s={wishlisted:j,"not-wishlisted":D,loading:M};i.forEach(l=>{l.style.backgroundImage=s[t],l.style.animation=t==="loading"?"jml-spin 1s linear infinite":"none",t==="wishlisted"?(l.classList.add("jewel_added_wishlist"),e&&(l.dataset.wishlistItemId=e)):t==="not-wishlisted"&&(l.classList.remove("jewel_added_wishlist"),delete l.dataset.wishlistItemId)})},window.jml.newWishlistAdd=async function(t,n,e,o){const i=t.split("_")[0];let s={productId:i,skuId:n};if(e){const r=await v(i,n);r&&(s.sellerId=r.sellerId)}const l=await N(()=>fetch(`/web-bff/wishlists/${window.jml.wishlistId}/add`,{method:"POST",credentials:"include",headers:C,body:JSON.stringify(s)}),{retryableCodes:new Set(["WishlistResponseBadRequestError"]),successCodes:new Set(["WishlistItemAlreadyAddedError"])});if(l.status==="success"){window.jml.wishlistUpdateUI("wishlisted",t,l.data?.wishlistItemId);const r=document.getElementById(`jml-wishlist-button-wrapper-${t}-${o}`);r&&g(r)}else throw new Error("Wishlist add failed")},window.jml.oldWishlistAdd=async function(t,n,e,o){const i=t.split("_")[0];let s={productId:i,skuId:n,wishlistId:window.jml.wishlistId??""};if(e){const r=await window.jml.getProductData(i,n);if(r){const a=r?.mainContent?.records?.at(0)?.allMeta?.variants.find(w=>w?.skuId===n)?.offers?.bestOffer;s.offerId=a?.offerId,s.sellerId=a?.sellerId,s.sellerSapSkuId=a?.sellerSkuId,s.sellerOperatorId=a?.sellerOperatorId}else throw new Error("Item data not found")}const l=await fetch("/addItemToWishlistApigee",{method:"PUT",credentials:"include",headers:{accept:"application/json","content-type":"application/json",brand:_,channel:"WEB"},body:JSON.stringify(s)});if(l.ok){const r=await l.json();window.jml.wishlistUpdateUI("wishlisted",t,r?.productAdded?.wishlistProdId);const a=document.getElementById(`jml-wishlist-button-wrapper-${t}-${o}`);a&&g(a)}else throw new Error("Wishlist add failed")},window.jml.wishlistAdd=async function(t,n,e,o){try{if(!window.jml.wishlistId)return;window.jml.wishlistUpdateUI("loading",t),window.jml.isStaging?await window.jml.newWishlistAdd(t,n,e,o):await window.jml.oldWishlistAdd(t,n,e,o);const i=window.jml.wishlistName||"tu lista";window.jml.isStaging?b.success(`Guardado en ${i}`):jml.showSuccessSnackbar(`Guardado en ${i}`)}catch{window.jml.wishlistUpdateUI("not-wishlisted",t),window.jml.isStaging?b.error("No se pudo agregar a tu lista. Intenta de nuevo."):window.jml.showAlertSnackbar("No se pudo agregar a tu lista. Intenta de nuevo.")}},window.jml.newWishlistRemove=async function(t,n){if((await N(()=>fetch(`/web-bff/wishlists/${window.jml.wishlistId}/items/${n}`,{method:"DELETE",credentials:"include",headers:{"x-brand-id":_}}),{retryableCodes:new Set(["WishlistResponseBadRequestError"]),successCodes:new Set(["WishlistResponseNotFoundError"])})).status==="success")window.jml.wishlistUpdateUI("not-wishlisted",t);else throw new Error("Wishlist remove failed")},window.jml.oldWishlistRemove=async function(t,n){const e=t.split("_")[0],l=(await(await fetch("/wishListSimpleApigee",{credentials:"include",headers:{accept:"application/json",brand:"LP",channel:"WEB"}})).json())?.lstWishList?.[0]?.id;if(!l||!n)throw new Error("Wishlist ID or wishlist product ID not found");if(!(await fetch("/deleteItemToWishlistApigee",{method:"PUT",credentials:"include",headers:{accept:"application/json","content-type":"application/json",brand:_,channel:"WEB"},body:JSON.stringify({wishlistId:l,wishlistProdId:n})})).ok)throw new Error("Wishlist remove failed");window.jml.wishlistUpdateUI("not-wishlisted",t)},window.jml.wishlistRemove=async function(t,n){try{if(!window.jml.wishlistId)return;window.jml.wishlistUpdateUI("loading",t),window.jml.isStaging?await window.jml.newWishlistRemove(t,n):await window.jml.oldWishlistRemove(t,n);const e=window.jml.wishlistName||"tu lista";window.jml.isStaging?b.success(`Eliminaste el producto de ${e} exitosamente.`):jml.showSuccessSnackbar(`Eliminaste el producto de ${e} exitosamente.`)}catch{window.jml.wishlistUpdateUI("wishlisted",t),window.jml.isStaging?b.error("No se pudo eliminar de tu lista. Intenta de nuevo."):window.jml.showAlertSnackbar("No se pudo eliminar de tu lista. Intenta de nuevo.")}},window.jml.wishlistButton=async function(t,n,e,o,i){if(t.preventDefault(),t.stopPropagation(),!window.jml.userIsLoggedIn)return;const s=document.getElementById(`jml-wishlist-button-wrapper-${n}-${e}`);s?.classList.contains("jewel_added_wishlist")?await window.jml.wishlistRemove(n,s.dataset.wishlistItemId):await window.jml.wishlistAdd(n,o,i,e)};async function h(t,n,e){try{const o="/web-bff",i={id:t,sku:n,quantity:jml.cartQuantity};if(c()==="click-collect"&&window.jml.userIsLoggedIn){const r=await x();i.initialAddress={storeId:String(r)}}e&&jml.cart.sellerInfo&&(i.sellerId=jml.cart.sellerInfo.sellerId,i.offerId=jml.cart.sellerInfo.offerId);const s=await fetch(`${o}/cart/items`,{method:"POST",headers:C,body:JSON.stringify(i)});return s.ok?{ok:!0}:{ok:!1,message:(await s.json().catch(()=>null))?.message}}catch{return{ok:!1}}}async function d(t,n,e,o){try{const i={quantity:jml.cartQuantity,catalogRefIds:n,productId:t,productType:o,isEDDCallRequired:"false"};if(e){const r=await window.jml.getProductData(t,n);if(r){const a=r?.mainContent?.records?.at(0)?.allMeta?.variants.find(w=>w?.skuId===n)?.offers?.bestOffer;i.offerId=a?.offerId,i.sellerId=a?.sellerId,i.sellerName=a?.sellerName,i.sellerSkuId=a?.sellerSkuId,i.sellerOperatorId=a?.sellerOperatorId}else throw new Error("Item data not found")}const s=await fetch("/addpdpitemtocart",{method:"POST",credentials:"include",headers:{"content-type":"application/json",accept:"application/json",brand:_,channel:"WEB"},body:JSON.stringify(i)});if(!s.ok)return{ok:!1};const l=await s.json().catch(()=>null);if(l?.formError){const r=Object.keys(l).find(a=>/^\d+$/.test(a)&&l[a]?.err);return{ok:!1,message:r?l[r].err:void 0}}return{ok:!0}}catch(i){return jml.errors=jml.errors??[],jml.errors.push(i.message),{ok:!1}}}window.jml.addToCart=async function(t,n,e,o,i,s){t.preventDefault(),t.stopPropagation();try{const l=n.split("_")[0];let r={ok:!1};if(window.jml.isStaging?r=await h(l,e,i):r=await d(l,e,i,s??"Soft Line"),!r.ok){const p="Ocurri\xF3 un error al agregar a tu bolsa.";return window.jml.isStaging?b.error(r.message||p):window.jml.showAlertSnackbar(r.message||p),r}window.jml.isStaging?b.success(`Agregaste ${window.jml.cartQuantity} art\xEDculo(s) a tu bolsa.`):window.jml.showSuccessSnackbar(`Agregaste ${window.jml.cartQuantity} art\xEDculo(s) a tu bolsa.`);const a=document.getElementById(`jml-addToCart-button-wrapper-${n}-${o}`),w=document.getElementById(`jml-mobileAddtoCart-button-wrapper-${n}-${o}`);a&&y(a),w&&y(w);const u=document.querySelector(`.jml-item-size-${e}-${o}`);if(u){const p=u.innerText;u.style.transition="all 0.25s ease-in-out",u.innerText="\u2714",setTimeout(()=>{u.innerText=p,u.style.transition="none"},1e3)}if(window.jml.isStaging){const p=document.querySelectorAll('[data-testid$="header-cart-quantity"]');p.length===0?document.querySelectorAll('[data-testid$="header-shopping-cart-shopping-link"]').forEach(f=>{const m=document.createElement("div");m.className="flex items-center justify-center w-[23px] h-[23px] text-body-sm font-semibold rounded-full bg-icon-alert text-header-icon absolute top-5 left-6",m.setAttribute("data-testid","bltc47588223af88ea0-header-shopping-cart-header-cart-quantity"),m.textContent="1",f.style.position="relative",f.appendChild(m)}):p.forEach(f=>{if(!f.textContent.includes("+")){const m=parseInt(f.textContent)+1;f.textContent=m>9?"9+":String(m)}})}else{const p=document.querySelectorAll(".a-header__bag>span");if(p.length===0){const f=document.createElement("span");f.innerText="1",document.querySelector(".a-header__bag").appendChild(f)}else if(!p[0].innerText.includes("+")){const f=parseInt(p[0].innerText)+1;f>9?p[0].innerText="9+":p[0].innerText=f}}return r}catch{return{ok:!1}}},window.jml.selectMobileCartSize=function(t,n){t.preventDefault(),t.stopPropagation();const e=jml.sizeOptions[parseInt(n)];window.jml.cart={size:e.size,offerId:jml.selectedProduct.productId,itemVariantId:e.skuId,unique:jml.selectedUnique,isMarketplace:e.isMarketplace,articleType:jml.selectedProduct.productType,sellerInfo:e.offers?.bestOffer},window.jml.updateCartUI({action:"size-changed"})},window.jml.addToCartMobile=async function(t,n){if(!window.jml.cart){window.jml.isStaging?b.warning("Por favor, selecciona una opci\xF3n"):window.jml.showAlertSnackbar("Por favor, selecciona una opci\xF3n");return}try{const e=document.getElementById("jml-mobile-cart-confirm-button-text"),o=document.getElementById("jml-mobile-cart-confirm-button-loading");e.style.display="none",o.style.display="block";const i=await window.jml.addToCart(t,jml.selectedOfferId,window.jml.cart.itemVariantId,window.jml.cart.unique,window.jml.cart.isMarketplace,window.jml.cart.articleType);e.style.display="block",o.style.display="none",i?.ok&&(n?window.jml.closeModalDesktop():window.jml.closeModalMobile())}catch{}},window.jml.sortSizes=t=>{const n=["Short","Regular","Long"],e=["2XCH","XXCH","XCH","CH","P","M","G","XG","2XG","XXG","3XG","XXXG","XXL","Est\xE1ndar","Euro","King","Matrimonial","Queen"],o=["32GB","32 GB","64GB","64 GB","128GB","128 GB","256GB","256 GB","512GB","512 GB","1TB","1 TB","2TB","2 TB","3TB","3 TB","4TB","4 TB","5TB","5 TB"],i=(s,l)=>s<l?-1:s>l?1:0;return[...t].sort((s,l)=>{const r=s.size,a=l.size;if(!r||!a)return 0;const w=r.split(" "),u=a.split(" "),p=w[0],f=u[0];if(o.includes(r)&&o.includes(a))return i(o.indexOf(r),o.indexOf(a));if(e.includes(p)&&e.includes(f))return i(e.indexOf(p),e.indexOf(f));const m=Number(p),I=Number(f);if(Number.isFinite(m)&&Number.isFinite(I)&&p!==""&&f!=="")return i(m,I);if(w.length>1&&u.length>1){const B=w[1],G=u[1];return n.includes(B)&&n.includes(G)?i(n.indexOf(B),n.indexOf(G)):i(r,a)}return i(r,a)})},window.jml.getVariantsInfo=async function(t,n){try{if(window.jml.isStaging){const{variants:m,colorSet:I,smallImage:B,id:G,productType:ee,brand:te,title:ne}=await fetch(`/web-bff/product/${t}`).then(W=>W.json()),J=m.map(W=>({...W,isMarketplace:!!W.bestOfferSellerName})),V=J.every(W=>!W.colorName),Z=V?[]:I,oe=V?[[...J]]:Z.map(({colorName:W})=>J.filter(X=>X.colorName.toLowerCase()===W.toLowerCase()||X.clothingBrandColor?.toLowerCase()===W.toLowerCase()));return{colorSet:Z,variantsByColor:oe,variants:J,defaultImage:B,productId:G,productType:ee,brand:te,title:ne,hasColor:!V}}const e=await fetch(`/tienda/oneColumnPageData?productId=${t}&pdpType=default${n?`&skuId=${n}`:""}`,{headers:{accept:"application/json, text/plain, */*",brand:_,channel:"WEB"}}).then(m=>m.json()),{variants:o,id:i,productImages:s,productType:l,brand:r,title:a}=e.mainContent.records[0].allMeta,w=o.map(m=>({skuId:m.skuId,colorName:m.color,clothingBrandColor:m.clothingBrandColor,colorHex:m.colorhex,smallImage:m.smallImage,size:m.size,title:m.skuName,isMarketplace:m.sellernames.some(I=>I.toLowerCase()!=="liverpool")})),u=w.every(m=>!m.colorName),p=u?[]:w.map(({clothingBrandColor:m,colorName:I,colorHex:B})=>({colorName:m??I,colorHex:B})).reduce((m,I)=>(m.find(({colorHex:G})=>G===I.colorHex)||m.push(I),m),[]),f=u?[[...w]]:p.map(({colorName:m})=>w.filter(I=>I.colorName.toLowerCase()===m.toLowerCase()||I.clothingBrandColor?.toLowerCase()===m.toLowerCase()));return{colorSet:p,variantsByColor:f,variants:w,productId:i,defaultImage:s[0].imageUrl,productType:l,brand:r,title:a,hasColor:!u}}catch(e){return jml.variantsError=e.stack,null}},window.jml.selectMobileCartColor=(t,n)=>{jml.selectedColor=parseInt(n),jml.cart=null,jml.sizeOptions=jml.sortSizes(jml.selectedProduct.variantsByColor[jml.selectedColor]),jml.hasSizes=jml.sizeOptions.find(e=>!!e.size)??!1,jml.hasSizes||window.jml.selectMobileCartSize(t,0),window.jml.updateCartUI({action:"color-changed"})},window.jml.buildColorPicker=()=>jml.selectedProduct.colorSet.map(({colorName:t,clothingBrandColor:n},e)=>`<button
        onclick="window.jml.selectMobileCartColor(event, '${e}');"
        style="padding:0px;outline:none;background-color:transparent;display:flex;flex-direction:column;align-items:center;justify-content:center;border:0px;"
      >
        <div style="background-color:transparent;position:relative;${e===jml.selectedColor?"border-radius:4px;border:1px solid #E10098":"border-radius:4px;border:1px solid transparent"};display:flex;flex-direction:column;align-items:center;justify-content:center;width:60px;height:78px;">
          <img src="${jml.selectedProduct.variantsByColor[e]?.at(0)?.smallImage??jml.selectedProduct.defaultImage}" style="width:100%;"></img>
          ${e===jml.selectedColor?`<div style="position:absolute;top:-12px;right:-8px">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M0 7C0 3.13401 3.13401 0 7 0C10.866 0 14 3.13401 14 7C14 10.866 10.866 14 7 14C3.13401 14 0 10.866 0 7Z" fill="#E10098"/>
              <path fill-rule="evenodd" clip-rule="evenodd" d="M9.85355 4.93551C10.0488 5.13077 10.0488 5.44735 9.85355 5.64262L6.28571 9.21045L4.14645 7.07119C3.95118 6.87593 3.95118 6.55934 4.14645 6.36408C4.34171 6.16882 4.65829 6.16882 4.85355 6.36408L6.28571 7.79624L9.14645 4.93551C9.34171 4.74025 9.65829 4.74025 9.85355 4.93551Z" fill="white"/>
            </svg>
          </div>`:""}
        </div>
        <p style="font-size:12px;margin:4px 0px 0px;color:${e===jml.selectedColor?"#333333":"#767676"};width:60px;">${n??t}</p>
      </button>`).join(""),window.jml.buildSizePicker=()=>jml.sizeOptions.map((t,n)=>`<button onclick="window.jml.selectMobileCartSize(event, '${n}');" 
        class="jewel-modal-product-button ${t.skuId===window.jml.cart?.itemVariantId?"jewel-modal-product-button-selected":""}">${t.size}</button>
        `).join(""),window.jml.buildQuantityPicker=()=>`
      <p style="font-family:robotomedium, Roboto-Medium;font-size:14px;margin:0px;">Cantidad:</p>
      <div style="display:flex;gap:8px;">
        <button onclick="window.jml.decrementQuantity()" style="outline:none;width:40px;height:40px;background-color:#F5F5F5;border:1px solid #C0C0C0;border-radius:4px;${jml.cartQuantity===1?"color:#C0C0C0":""}">-</button/>
        <p style="margin:0px;height:40px;width:64px;background-color:transparent;border:1px solid #C0C0C0;border-radius:4px;text-align:center;line-height:40px;">${jml.cartQuantity}</p>
        <button onclick="window.jml.incrementQuantity()" style="outline:none;width:40px;height:40px;background-color:#F5F5F5;border:1px solid #C0C0C0;border-radius:4px;">+</button/>
      </div>`,window.jml.incrementQuantity=()=>{jml.cartQuantity+=1;const t=document.getElementById("jml-mobile-cart-quantity-picker");t.innerHTML=window.jml.buildQuantityPicker()},window.jml.decrementQuantity=()=>{if(jml.cartQuantity>1){jml.cartQuantity-=1;const t=document.getElementById("jml-mobile-cart-quantity-picker");t.innerHTML=window.jml.buildQuantityPicker()}},window.jml.updateCartUI=({action:t})=>{if(t==="color-changed"&&jml.selectedProduct.hasColor){const n=document.getElementById("jml-mobile-cart-selected-color");n.innerText=jml.selectedProduct.colorSet[jml.selectedColor].colorName;const e=document.getElementById("jml-mobile-cart-color-pickers");e.innerHTML=window.jml.buildColorPicker();const o=document.getElementById("jml-mobile-cart-main-image");o.src=jml.sizeOptions?.at(0)?.smallImage??jml.selectedProduct.defaultImage}if(jml.hasSizes){const n=document.getElementById("jml-mobile-cart-selected-size");n.innerText=window.jml?.cart?.size??"Selecciona una opci\xF3n";const e=document.getElementById("jml-mobile-cart-size-pickers");e.innerHTML=window.jml.buildSizePicker()}},window.jml.buildImageSkeleton=()=>`
    <div class="jml-skeleton" style="width: 80px; height: 104px;"></div>
  `,window.jml.buildImage=(t,n)=>`
    <img id="jml-mobile-cart-main-image" src="${t}" alt="${n}" style="width: 80px; height: 104px; object-fit: contain; border-radius: 4px;">
  `,window.jml.buildMetaSkeleton=()=>`
    <div style="display: flex; flex-direction: column; gap: 8px; padding-top: 4px;">
      <div class="jml-skeleton" style="width: 90px; height: 16px;"></div>
      <div class="jml-skeleton" style="width: 180px; height: 16px;"></div>
      <div class="jml-skeleton" style="width: 140px; height: 16px;"></div>
    </div>
  `,window.jml.buildMeta=(t,n)=>`
    <p style="margin-bottom: 0px; font-size: 16px; font-weight: 600; color: #000; line-height: 20.8px; font-family: 'robotoRegular', sans-serif;">${t}</p>
    <p style="margin-bottom: 0px; font-size: 16px; font-weight: 400; color: #000; line-height: 20.8px; font-family: 'robotoRegular', sans-serif;">${n}</p>
  `,window.jml.buildOptionsSkeleton=()=>`
    <div class="jml-skeleton" style="display:block;height: 48px; margin: 24px 0 16px 0; border-radius: 8px;"></div>
    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
      <div class="jml-skeleton" style="width: 60px; height: 78px;"></div>
      <div class="jml-skeleton" style="width: 60px; height: 78px;"></div>
      <div class="jml-skeleton" style="width: 60px; height: 78px;"></div>
      <div class="jml-skeleton" style="width: 60px; height: 78px;"></div>
    </div>
    <div class="jml-skeleton" style="display:block;height: 48px; margin: 24px 0 16px 0; border-radius: 8px;"></div>
    <div style="display: flex; flex-wrap: wrap; gap: 8px 12px;">
      <div class="jml-skeleton" style="width: 64px; height: 40px;"></div>
      <div class="jml-skeleton" style="width: 64px; height: 40px;"></div>
      <div class="jml-skeleton" style="width: 64px; height: 40px;"></div>
      <div class="jml-skeleton" style="width: 64px; height: 40px;"></div>
      <div class="jml-skeleton" style="width: 64px; height: 40px;"></div>
    </div>
  `,window.jml.buildOptions=()=>{const t=jml.selectedProduct.hasColor?`
      <div style="background-color: #f5f5f5; padding: 8px; border-radius: 8px; height: 48px; display: flex; flex-direction: row; gap: 4px; align-items: center; margin: 24px 0 16px 0;">
        <p style="margin: 0; font-size: 14px; font-weight: 600; color: #333333;">Color:</p>
        <p id="jml-mobile-cart-selected-color" style="margin: 0; font-size: 14px; font-weight: 400; color: #333333;">${jml.selectedProduct.colorSet[jml.selectedColor].colorName}</p>
      </div>
      <div id="jml-mobile-cart-color-pickers" style="display: flex; gap: 8px; align-items: start;flex-wrap:wrap">
        ${window.jml.buildColorPicker()}
      </div>
    `:"",n=jml.hasSizes?`
      <div id="jml-mobile-cart-size-container">
        <div style="background-color: #f5f5f5; padding: 8px; border-radius: 8px; height: 48px; display: flex; flex-direction: row; gap: 4px; align-items: center; margin: 24px 0 16px 0;">
          <p style="margin: 0; font-size: 14px; font-weight: 600; color: #333333;">Talla:</p>
          <p id="jml-mobile-cart-selected-size" style="margin: 0; font-size: 14px; font-weight: 400; color: #333333;">Selecciona una opci\xF3n</p>
        </div>
        <div id="jml-mobile-cart-size-pickers" style="display: flex; flex-wrap: wrap; gap: 8px 12px;">
          ${window.jml.buildSizePicker()}
        </div>
      </div>
    `:"";return t+n},window.jml.populateModalContent=(t,n,e)=>{const o=document.getElementById("jml-cart-image-wrapper"),i=document.getElementById("jml-cart-product-meta"),s=document.getElementById("jml-cart-options"),l=document.getElementById("jml-mobile-cart-confirm-button");if(!o||!i||!s)return;if(!jml.selectedProduct){i.innerHTML='<p style="color:#b50000;font-size:14px;margin:0;padding:8px 0;">No se pudo cargar la informaci\xF3n del producto.</p>',s.innerHTML="";return}const r=jml.selectedProduct.variants.find(({skuId:p})=>n===p)??jml.selectedProduct.variants[0];if(jml.selectedColor=jml.selectedProduct.hasColor?jml.selectedProduct.colorSet.findIndex(({colorName:p})=>r.colorName.toLowerCase()===p.toLowerCase()||r.clothingBrandColor?.toLowerCase()===p.toLowerCase()):0,jml.selectedColor===-1&&(jml.selectedColor=0),jml.sizeOptions=jml.sortSizes(jml.selectedProduct.variantsByColor[jml.selectedColor]),jml.hasSizes=jml.sizeOptions.find(p=>!!p.size)??!1,!jml.hasSizes){if(!jml.sizeOptions.at(0)){i.innerHTML='<p style="color:#b50000;font-size:14px;margin:0;padding:8px 0;">No se pudo cargar la informaci\xF3n del producto.</p>',s.innerHTML="";return}window.jml.selectMobileCartSize(t,0)}const a=jml.sizeOptions?.at(0)?.smallImage??jml.selectedProduct.defaultImage,w=jml.selectedProduct.title,u=jml.selectedProduct.brand;o.innerHTML=window.jml.buildImage(a,w),i.innerHTML=window.jml.buildMeta(u,w),s.innerHTML=window.jml.buildOptions(),l&&l.removeAttribute("disabled")},window.jml.openModalMobile=async function(t,n,e,o){t.preventDefault(),t.stopPropagation();try{document.querySelector("html").classList.add("noscroll"),window.jml.cart=null,jml.selectedProduct=null,jml.sizeOptions=null,jml.selectedUnique=o,jml.selectedOfferId=n,jml.cartQuantity=1;const s=n.split("_").length>1?n.split("_")[0]:n,l=`<div id="jml-mobile-modal" role="presentation" data-testid="base-modal" style="position: fixed; inset: 0px; z-index: 999999;">
        <div tabindex="-1" class="jml-mobile-modal">
          <div class="jewel-modal-content">
            <div class="jewel-modal-product">
              <div class="jewel-modal-product-header">
                <p class="jewel-modal-product-title" style="font-family:robotomedium, Roboto-Medium;">Selecciona una opci\xF3n</p>
                <div class="jewel-modal-product-close-button" onclick="window.jml.closeModalMobile()">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="#333333"/>
                  </svg>
                </div>
              </div>
              <div class="jewel-modal-product-content">
                <div style="padding: 16px 16px 24px 16px;overflow-y:auto;max-height: 75svh;">
                  <div style="display: flex; flex-direction: row; gap: 16px;">
                    <div id="jml-cart-image-wrapper" style="flex: 0 0 80px;">
                      ${window.jml.buildImageSkeleton()}
                    </div>
                    <div id="jml-cart-product-meta" style="display: flex; flex-direction: column; flex: 1; min-width: 0;">
                      ${window.jml.buildMetaSkeleton()}
                    </div>
                  </div>
                  <div id="jml-cart-options">
                    ${window.jml.buildOptionsSkeleton()}
                  </div>
                  <div id="jml-mobile-cart-quantity-picker" style="margin-top:24px;display:flex;justify-content:space-between;align-items:center;">
                    ${window.jml.buildQuantityPicker()}
                  </div>
                </div>
                <div style="padding: 16px 16px 24px 16px; border-top: 1px solid #f5f5f5;">
                  <button id="jml-mobile-cart-confirm-button" class="jewel-modal-confirm-button" onclick="window.jml.addToCartMobile(event,false)" disabled style="display:flex;align-items:center;justify-content:center;">
                    <p id="jml-mobile-cart-confirm-button-text" style="margin: 0;">Agregar a mi bolsa</p>
                    <div id="jml-mobile-cart-confirm-button-loading" style="display: none;" class="jml-loading-animation">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      >
                        <path d="M21 12a9 9 0 11-6.219-8.56" />
                      </svg>
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div onclick="window.jml.closeModalMobile()" class="jewel-modal-backdrop-container" data-testid="modal-backdrop-container" style="animation: show-jml-modal-backdrop 0.3s ease-in-out;">
          <div role="presentation" class="jewel-modal-backdrop"></div>
        </div>
      </div>`;document.body.appendChild(document.createRange().createContextualFragment(l));try{const r=document.getElementById(`jml-mobileAddtoCart-button-wrapper-${n}-${o}`);jml.pageModel=$(r),window.dataLayer.push({event:"jewel_pdp_view",jml_page:window.location.pathname,jml_query:window.location.search,jewel_model_name:jml.pageModel})}catch{}if(jml.selectedProduct=await window.jml.getVariantsInfo(s,n),!document.getElementById("jml-mobile-modal"))return;window.jml.populateModalContent(t,e,!1)}catch(i){window.jml.fail=i.stack}},window.jml.closeModalMobile=function(){document.querySelector("html").classList.remove("noscroll");const n=document.getElementById("jml-mobile-modal"),e=document.querySelector(".jewel-modal-backdrop-container"),o=document.querySelector(".jewel-modal-content");n&&(o.style.animation="hide-jml-modal 0.3s ease-in-out",e.style.animation="hide-jml-modal-backdrop 0.3s ease-in-out",n.addEventListener("animationend",()=>n.remove())),jml.pageModel=null},window.jml.openModalDesktop=async function(t,n,e,o){t.preventDefault(),t.stopPropagation(),jml.fail=void 0;try{document.querySelector("html").classList.add("noscroll"),window.jml.cart=null,jml.selectedProduct=null,jml.sizeOptions=null,jml.selectedUnique=o,jml.selectedOfferId=n,jml.cartQuantity=1;const s=n.split("_").length>1?n.split("_")[0]:n,l=`<div id="jml-mobile-modal" role="presentation" data-testid="base-modal" style="position: fixed; inset: 0px; z-index: 999999;">
        <div tabindex="-1" class="jml-mobile-modal">
          <div class="jewel-modal-content" style="animation: show-jml-modal-desktop 0.3s ease-in-out;">
            <div class="jewel-modal-product">
              <div class="jewel-modal-product-header">
                <p class="jewel-modal-product-title" style="font-family:robotomedium, Roboto-Medium;">Selecciona una opci\xF3n</p>
                <div class="jewel-modal-product-close-button" onclick="window.jml.closeModalDesktop()">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="#333333"/>
                  </svg>
                </div>
              </div>
              <div class="jewel-modal-product-content">
                <div style="padding: 16px 16px 0px 16px;overflow-y:auto;max-height: calc(100svh - 137px);">
                  <div style="display: flex; flex-direction: row; gap: 16px;">
                    <div id="jml-cart-image-wrapper" style="flex: 0 0 80px;">
                      ${window.jml.buildImageSkeleton()}
                    </div>
                    <div style="display: flex; flex-direction: column; flex: 1; min-width: 0;">
                      <div id="jml-cart-product-meta">
                        ${window.jml.buildMetaSkeleton()}
                      </div>
                      <div>
                        <div id="jml-cart-options">
                          ${window.jml.buildOptionsSkeleton()}
                        </div>
                        <div id="jml-mobile-cart-quantity-picker" style="margin-top:24px;display:flex;justify-content:space-between;align-items:center;">
                          ${window.jml.buildQuantityPicker()}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div style="height:1px;width:100%;border-bottom: 1px solid #D8D8D8;padding:32px 16px 24px 16px"></div>
                </div>
                <div style="padding: 16px 16px 24px 16px;">
                  <button id="jml-mobile-cart-confirm-button" class="jewel-modal-confirm-button" onclick="window.jml.addToCartMobile(event,true)" disabled style="display:flex;align-items:center;justify-content:center;">
                    <p id="jml-mobile-cart-confirm-button-text" style="margin: 0;">Agregar a mi bolsa</p>
                    <div id="jml-mobile-cart-confirm-button-loading" style="display: none;" class="jml-loading-animation">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      >
                        <path d="M21 12a9 9 0 11-6.219-8.56" />
                      </svg>
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div onclick="window.jml.closeModalDesktop()" class="jewel-modal-backdrop-container" data-testid="modal-backdrop-container" style="animation: show-jml-modal-backdrop 0.3s ease-in-out;">
          <div role="presentation" class="jewel-modal-backdrop"></div>
        </div>
      </div>`;document.body.appendChild(document.createRange().createContextualFragment(l));try{const r=document.getElementById(`jml-mobileAddtoCart-button-wrapper-${n}-${o}`);jml.pageModel=$(r),window.dataLayer.push({event:"jewel_pdp_view",jml_page:window.location.pathname,jml_query:window.location.search,jewel_model_name:jml.pageModel})}catch{}if(jml.selectedProduct=await window.jml.getVariantsInfo(s,n),!document.getElementById("jml-mobile-modal"))return;window.jml.populateModalContent(t,e,!0)}catch(i){window.jml.fail=i.stack}},window.jml.closeModalDesktop=function(){document.querySelector("html").classList.remove("noscroll");const n=document.getElementById("jml-mobile-modal"),e=document.querySelector(".jewel-modal-backdrop-container"),o=document.querySelector(".jewel-modal-content");n&&(o.style.animation="hide-jml-modal-desktop 0.3s ease-in-out",e.style.animation="hide-jml-modal-backdrop 0.3s ease-in-out",n.addEventListener("animationend",()=>n.remove())),jml.pageModel=null};function y(t){const{itemName:n,modelName:e,offerId:o}=k(t);window.dataLayer.push({event:"jewel_cart_click",jewel_item_name:n,jewel_model_name:e,jewel_offer_id:o,model:e,value:n})}function g(t){const{itemName:n,modelName:e,offerId:o}=k(t);window.dataLayer.push({event:"jewel_favorite_click",jewel_item_name:n,jewel_model_name:e,jewel_offer_id:o,model:e,value:n})}function k(t){if(t){let n=T(t,["_jml_grid_item","_jml_carousel_slide"]),[e,o,i]=z(n);return{itemName:e,modelName:o,offerId:i}}}function $(t){if(t){let n=T(t,["_jml_grid_item","_jml_carousel_slide"]),[e,o,i]=z(n);return o}}function T(t,n){let e=t.parentElement;for(;e;){for(let o of n)if(e.classList.contains(o))return e;e=e.parentElement}return null}function E(t,n){let e=t.parentElement;for(;e;){if(e.classList.contains(n))return e;e=e.parentElement}return null}function z(t){let n=t.querySelector("._jml_section_item_link_css").innerText.trim(),e=t.querySelector("[data-jmlmodel]"),o=e.getAttribute("data-jmlmodel").trim(),i=e.getAttribute("offer-id").trim();return[n,o,i]}})())):window.__jml_custom_function=(()=>{window.jml.isStaging=!0;const _="LP";window.jml.userIsLoggedIn=!1;const R="jml-hide-add-to-cart";function O(){if(document.getElementById(R))return;const t=document.createElement("style");t.id=R,t.textContent=`
      ._jml_carousel_slide .jml-add-to-cart-wrapper {
        display: none !important;
      }
      ._jml_carousel_slide:hover .jml-add-to-cart-wrapper {
        display: none !important;
      }
      ._jml_carousel_slide._jml_carousel_slide:hover .jml-add-to-cart-wrapper.jml-add-to-cart-wrapper {
          display: none !important;
      }

      [id^="jml-mobileAddtoCart-button-wrapper-"] {
        display: none !important;
      }
    `,document.head.appendChild(t)}function U(){const t=document.getElementById(R);t&&t.remove()}function q(t,n){const e=new Date;e.setFullYear(e.getFullYear()+1),document.cookie=[t+"="+encodeURIComponent(n),"path=/","expires="+e.toUTCString(),"SameSite=Lax"].join("; ")}function S(t){document.cookie=`${t}=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax`}jml.checkAuthState=()=>{O();function t(i){const s=document.cookie.match(new RegExp("(^| )"+i+"=([^;]+)"));return s?s[2]:null}if(t("x-cs-folio-id"))return;const e=`jml_userid_${jml.integration_id}`,o=localStorage.getItem("jewel_hashed_userid");o&&o!==" "&&o!=="null"&&o!=="undefined"&&o!=="na"?(window.jml.userIsLoggedIn=!0,localStorage.setItem(e,o),window.jml.wishlistUpdate(),U()):(window.jml.userIsLoggedIn=!1,localStorage.removeItem(e),S(e))};let P=null;jml.oldCheckAuthState=()=>{P&&clearInterval(P),P=setInterval(()=>{if(!window.getProfileId||!window.getProfileId())return;const t=window.getProfileId();if(!t||t===""||t==="undefined"||t==="null"){window.jml.userIsLoggedIn=!1;const n=`jml_userid_${jml.integration_id}`;localStorage.removeItem(n),S(n)}else window.jml.userIsLoggedIn=!0,window.jml.wishlistUpdate();clearInterval(P)},100)};async function F(t){const n=new TextEncoder,e=await crypto.subtle.importKey("raw",n.encode("jewelml"),{name:"HMAC",hash:"SHA-256"},!1,["sign"]),o=await crypto.subtle.sign("HMAC",e,n.encode(t));return Array.from(new Uint8Array(o)).map(i=>i.toString(16).padStart(2,"0")).join("")}const A=function(){const t=localStorage.setItem.bind(localStorage),n=localStorage.removeItem.bind(localStorage),e=localStorage.clear.bind(localStorage);localStorage.setItem=function(o,i){const s=localStorage.getItem(o);t(o,i),window.dispatchEvent(new CustomEvent("jml:ls-change",{detail:{type:"set",key:o,value:i,oldValue:s}}))},localStorage.removeItem=function(o){const i=localStorage.getItem(o);n(o),window.dispatchEvent(new CustomEvent("jml:ls-change",{detail:{type:"remove",key:o,oldValue:i}}))},localStorage.clear=function(){e(),window.dispatchEvent(new CustomEvent("jml:ls-change",{detail:{type:"clear"}}))},window.addEventListener("jml:ls-change",({detail:{key:o,type:i,value:s}})=>{o&&((o.startsWith("jml_userid_")||o.startsWith("jml_uuid_"))&&i==="set"&&q(o,s),o==="jewel_hashed_userid"&&setTimeout(()=>jml.checkAuthState()))}),setTimeout(()=>{const o=i=>{const s=localStorage.getItem(i);s&&q(i,s)};o(`jml_uuid_${jml.integration_id}`),o(`jml_userid_${jml.integration_id}`);try{if(!localStorage.getItem(`jml_uuid_${window.jml.integration_id}`)){const s=crypto.randomUUID();localStorage.setItem(`jml_uuid_${window.jml.integration_id}`,s)}}catch{}})};localStorage?A():setTimeout(()=>A()),window.jml.sendJewelViewItem=t=>{window.location.pathname.startsWith("/tienda/pdp/")&&t!=="empty"&&window.dataLayer.push({event:"jewel_view_item",item_id:t})},setTimeout(()=>{try{const n=localStorage.getItem("jml_userid_67fd95260740ccc4ec658d03");["7ffff06e660184dcf111c63dab65561abba1bff7ca050cae8bc0e8c392398092"].includes(n)&&localStorage.removeItem("jml_userid_67fd95260740ccc4ec658d03")}catch{}window.jml.personalizedSavedModels=[...window.jml.personalizedSavedModels,"recently-viewed-items-global","recently-viewed-items-global-dev"];let t=window.jml.item_id;window.jml.sendJewelViewItem(t),Object.defineProperty(window.jml,"item_id",{configurable:!0,enumerable:!0,get(){return t},set(n){const e=t;t=n,n!==e&&window.dispatchEvent(new CustomEvent("jml:item_id_changed",{bubbles:!0,detail:{oldValue:e,newValue:n,timestamp:Date.now()}}))}}),window.addEventListener("jml:item_id_changed",function(n){const{newValue:e}=n.detail;window.jml.sendJewelViewItem(e)}),window.jml.isStaging=isGcpMigrated(),window.jml.integration_id&&(window.jml.isStaging?jml.checkAuthState():jml.oldCheckAuthState())});const L=document.createElement("style");L.type="text/css",L.textContent=`
  .o-carousel-section {
      display: none !important;
  }
  .wishlist-snackbar {
      z-index: 9999999999 !important;
  }
  `,window.jml.isStaging&&(L.textContent+=`
      section[data-testid*="container-similar-products-grid"] {
        padding-top: 0px !important;
      }
      section[data-testid*="container-similar-products-grid"] > div:not([id]) {
        display: none;
      }

      div[id*="jml-carousel"] {
        margin-top: 32px !important;
      }
    `),L.textContent+=`
    @keyframes jml-spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    @keyframes jml-skeleton-shimmer {
      0% { background-position: -240px 0; }
      100% { background-position: calc(240px + 100%) 0; }
    }
    .jml-skeleton {
      background-color: #efefef;
      background-image: linear-gradient(90deg, #efefef 0%, #e4e4e4 50%, #efefef 100%);
      background-size: 240px 100%;
      background-repeat: no-repeat;
      animation: jml-skeleton-shimmer 1.4s ease-in-out infinite;
      border-radius: 4px;
      display: inline-block;
    }
    .jewel-modal-confirm-button[disabled] {
      opacity: 0.5;
      cursor: not-allowed;
    }
  `,document.head.appendChild(L);const j="url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNyIgaGVpZ2h0PSIxNyIgdmlld0JveD0iMCAwIDE3IDE3IiBmaWxsPSJub25lIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0yLjE0NTUxIDUuOTM3OUMyLjE0NTUxIDMuODA4MzkgMy44NDgxNCAyLjE0MDg3IDUuOTg0MjEgMi4xNDA4N0M2LjkzOTk4IDIuMTQwODcgNy44NjAxMSAyLjQ4Nzk0IDguNTc1MDkgMy4wNjgzMUM5LjI5MDA2IDIuNDg3OTQgMTAuMjEwMiAyLjE0MDg3IDExLjE2NiAyLjE0MDg3QzEzLjMwMiAyLjE0MDg3IDE1LjAwNDcgMy44MDgzOSAxNS4wMDQ3IDUuOTM3OUMxNS4wMDQ3IDcuMjM1NDQgMTQuNDA3MiA4LjM1ODg0IDEzLjUwMDggOS40NTMyMkMxMi42MTMxIDEwLjUyNDkgMTEuMzU5NSAxMS42NDkxIDkuOTE0MTcgMTIuOTQ1Mkw5Ljg1ODYzIDEyLjk5NUw5Ljg1NzE4IDEyLjk5NjNMOC41NzMzOCAxNC4xNDA5TDcuMjkxMTEgMTIuOTg4OUw3LjI1MDc5IDEyLjk1MjhDNS43OTkzIDExLjY1NCA0LjU0MDI3IDEwLjUyNzMgMy42NDk1NSA5LjQ1MjY4QzIuNzQyOTcgOC4zNTg4OCAyLjE0NTUxIDcuMjM1NDUgMi4xNDU1MSA1LjkzNzlaIiBmaWxsPSIjZTEwMDk4Ii8+Cjwvc3ZnPg==')",M="url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNyIgaGVpZ2h0PSIxNyIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIj48Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSI5IiBzdHJva2U9IiNlMTAwOTgiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtZGFzaGFycmF5PSI0MiAxNCIvPjwvc3ZnPg==')",D="url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTciIHZpZXdCb3g9IjAgMCAxNiAxNyIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik01LjE3MjA4IDMuNTA0MThDMy43NjE1MiAzLjUwNDE4IDIuNjc3NTIgNC41ODY2MyAyLjY3NzUyIDUuOTU3MDdDMi42Nzc1MiA2LjgwNzIzIDMuMDU4ODQgNy42MzI2NCAzLjg3MjMxIDguNjE0MDlDNC42OTMyMSA5LjYwNDUxIDUuODgwMDcgMTAuNjY4NCA3LjM3NjI5IDEyLjAwNzNMNy4zNzcyNiAxMi4wMDgyTDcuNzY0NjYgMTIuMzU2Mkw4LjE0OTA5IDEyLjAxMzVDOC4xNDkzMyAxMi4wMTMyIDguMTQ5NTYgMTIuMDEzIDguMTQ5OCAxMi4wMTI4QzkuNjQ1ODQgMTAuNjcxMiAxMC44MzI1IDkuNjA2MTEgMTEuNjUzNSA4LjYxNDk3QzEyLjQ2NzEgNy42MzI2OCAxMi44NDg0IDYuODA3MjQgMTIuODQ4NCA1Ljk1NzA3QzEyLjg0ODQgNC41ODY2MyAxMS43NjQ0IDMuNTA0MTggMTAuMzUzOCAzLjUwNDE4QzkuNTUyMjIgMy41MDQxOCA4Ljc3NDgzIDMuODc1NyA4LjI3MTc4IDQuNDU4NjdMNy43NjI5NSA1LjA0ODMyTDcuMjU0MTMgNC40NTg2N0M2Ljc1MTA4IDMuODc1NyA1Ljk3MzY5IDMuNTA0MTggNS4xNzIwOCAzLjUwNDE4Wk0xLjMzMzM3IDUuOTU3MDdDMS4zMzMzNyAzLjgyNzU1IDMuMDM2MDEgMi4xNjAwMyA1LjE3MjA4IDIuMTYwMDNDNi4xMjc4NSAyLjE2MDAzIDcuMDQ3OTggMi41MDcxMSA3Ljc2Mjk1IDMuMDg3NDhDOC40Nzc5MyAyLjUwNzExIDkuMzk4MDYgMi4xNjAwMyAxMC4zNTM4IDIuMTYwMDNDMTIuNDg5OSAyLjE2MDAzIDE0LjE5MjUgMy44Mjc1NSAxNC4xOTI1IDUuOTU3MDdDMTQuMTkyNSA3LjI1NDYgMTMuNTk1MSA4LjM3OCAxMi42ODg2IDkuNDcyMzhDMTEuODAxIDEwLjU0NDEgMTAuNTQ3NCAxMS42NjgzIDkuMTAyMDMgMTIuOTY0NEw5LjA0NjQ5IDEzLjAxNDJMOS4wNDUwNCAxMy4wMTU1TDcuNzYxMjUgMTQuMTZMNi40Nzg5NyAxMy4wMDgxTDYuNDM4NjUgMTIuOTcyQzQuOTg3MTcgMTEuNjczMSAzLjcyODE0IDEwLjU0NjUgMi44Mzc0MiA5LjQ3MTg1QzEuOTMwODMgOC4zNzgwNCAxLjMzMzM3IDcuMjU0NjEgMS4zMzMzNyA1Ljk1NzA3WiIgZmlsbD0iIzVDNUM1QyIvPgo8L3N2Zz4K')",C={"x-brand-id":_,"Content-Type":"application/json"};window.jml.getProductById=async t=>await(await fetch(`/web-bff/product/${t}`,{headers:C})).json(),window.jml.redirects=(t,n)=>{if(window.jml.isStaging){let u=function(f){const m=document.querySelector(`[offer-id="${f}"]`);return m?m.closest("._jml_card_wrapper")?.querySelector("[data-variant]")?.getAttribute("data-variant")??null:null};var a=u;if(!(n.split("_").length>1)){window.next.router.push(t);return}const p=u(n);window.next.router.push(`${t}&skuid=${p}`);return}const e=t.match(/\/tienda\/pdp\/([^\/]+(?:\/[^\/]+)*)\/(\d+)/);if(!e)return;const o=e[1],i=t.split("/").at(-1).split("?")[0],l=`/tienda/oneColumnPage?productName=${o.split("-").map(w=>w.charAt(0).toUpperCase()+w.slice(1)).join("-")}&productId=${i}&pdpTypeForSPA=default&skuId=${n||i}`,r=`${t}${t.includes("?")?"&":"?"}skuid=${n.split("_")[0]||i}`;window.next.router.push(l,r,{scroll:!1}),window.scrollTo({top:0,behavior:"smooth"})},window.jml.updateTPSTitle=jml.debounce(async function(){const t=document.querySelector('[data-jmlmodel="T_prod"]');if(!t)return;let n=t.closest('[id$="-jml-carousel"]');if(!n)return;const e=n.querySelector("._jml_section_title_css");if(!e)return;let o=null;try{const i=[],s=window.jml.isStaging?'[data-testid$="-breadcrumb-ul"]':".m-breadcrumb-list";if(document.querySelector(s)?.childNodes?.forEach(l=>{i.push(l.innerText)}),i.length>1)o=i.at(-1).trim().toLowerCase();else{const l=window.location.pathname.split("/").at(-1);if(window.jml.isStaging){const{categoryBreadCrumbs:r}=await window.jml.getProductById(l);o=r.at(-1).categoryName.trim().toLowerCase()}else{const r=await fetch("/getpdpdynamiccontent",{method:"POST",body:JSON.stringify({productId:l})});r.ok&&(o=(await r.json()).breadCrumbs.at(-1).categoryName.trim().toLowerCase())}}}catch{}o&&(e.textContent=`Los m\xE1s vendidos en ${o}`)},50),window.jml.getProductData=async(t,n)=>{const e=await fetch(`/tienda/oneColumnPageData?productId=${t}&pdpType=default&skuId=${n}`,{method:"GET",credentials:"include",headers:{"content-type":"application/json",accept:"application/json",brand:_,channel:"WEB"}});return e.ok?await e.json():null},window.jml.showSnackbar=(t,n="success",e=3e3)=>{const o=document.querySelectorAll(".mdc-snackbar");o.forEach((a,w)=>{a.style.margin="6px",a.setAttribute("data-debug-index",w)});const i=o[n==="success"?1:n==="warning"?2:0],s=document.querySelectorAll(".m-alert__container.mdc-snackbar")[1],l=document.querySelectorAll(".a-alert__icon")[1],r=i.querySelector(".mdc-snackbar__label");r&&(r.textContent=t),s.classList.contains("-alert")&&s.classList.remove("-alert"),l.classList.contains("icon-error")&&(l.classList.remove("icon-error"),l.classList.add("icon-done")),s.classList.add("-success"),i.classList.add("mdc-snackbar--open"),i.offsetWidth,setTimeout(()=>{i.classList.remove("mdc-snackbar--open"),l.classList.add("icon-error"),l.classList.remove("icon-done")},e)},window.jml.showAlertSnackbar=(t,n=3e3)=>{const e=document.querySelector(".m-alert__container.mdc-snackbar.-alert")||document.querySelector(".m-alert__container.mdc-snackbar");if(!e)return;e.classList.add("-alert"),e.classList.remove("-success");const o=e.querySelector(".a-alert__icon");o&&(o.classList.add("icon-error"),o.classList.remove("icon-done"));const i=e.querySelector(".mdc-snackbar__label");i&&(i.textContent=t),e.classList.add("mdc-snackbar--open"),e.offsetWidth,setTimeout(()=>{e.classList.remove("mdc-snackbar--open")},n)},window.jml.showSuccessSnackbar=(t,n=3e3)=>{const e=document.querySelector(".m-alert__container.mdc-snackbar.-success")||document.querySelector(".m-alert__container.mdc-snackbar");if(!e)return;e.classList.add("-success"),e.classList.remove("-alert");const o=e.querySelector(".a-alert__icon");o&&(o.classList.add("icon-done"),o.classList.remove("icon-error"));const i=e.querySelector(".mdc-snackbar__label");i&&(i.textContent=t),e.classList.add("mdc-snackbar--open"),e.offsetWidth,setTimeout(()=>{e.classList.remove("mdc-snackbar--open")},n)};const b=(()=>{const t={success:{bg:"rgb(231, 248, 236)",color:"rgb(7, 134, 44)",icon:"check_circle_outline"},error:{bg:"rgb(255, 230, 230)",color:"rgb(181, 0, 0)",icon:"error_outline"},warning:{bg:"rgb(253, 245, 230)",color:"rgb(168, 112, 0)",icon:"warning_amber"},info:{bg:"rgb(235, 247, 249)",color:"rgb(39, 121, 141)",icon:"info_outline"}};function n(){if(document.getElementById("jewel-toast-styles"))return;const l=document.createElement("style");l.id="jewel-toast-styles",l.textContent=`
        #jewel-toast-root {
          position: fixed;
          top: 128px;
          left: 0;
          right: 0;
          z-index: 99999999;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          padding: 0px 16px 12px 16px;
          pointer-events: none;
          box-sizing: border-box;
        }

        /* Desktop: respect the navbar height (128px) + extra breathing room */
        @media (min-width: 768px) {
          #jewel-toast-root {
            padding: 0;
          }
        }

        .jewel-toast {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          width: 100%;
          max-width: 688px;
          padding: 13px 12px;
          border-radius: 4px;
          box-shadow: rgba(20, 20, 20, 0.12) 0px 6px 12px 0px;
          font-family: Gotham-Medium, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          font-size: 12px;
          font-weight: 500;
          line-height: 1.4;
          box-sizing: border-box;
          pointer-events: all;
          height: 48px;

          /* Entrance animation */
          opacity: 0;
          transform: translateY(-10px);
          transition: opacity 220ms ease, transform 220ms ease;
        }

        /* On mobile: full width with horizontal margins handled by root padding */
        @media (max-width: 767px) {
          .jewel-toast {
            max-width: 100%;
            font-size: 12px;
            padding: 14px 14px;
          }
        }

        .jewel-toast.jewel-toast--visible {
          opacity: 1;
          transform: translateY(0);
        }

        .jewel-toast--exit {
          opacity: 0 !important;
          transform: translateY(-10px) !important;
        }

        .jewel-toast__body {
          display: flex;
          align-items: center;
          gap: 8px;
          flex: 1;
          min-width: 0;
        }

        .jewel-toast__icon {
          font-family: 'Material Icons';
          font-size: 16px;
          font-style: normal;
          font-weight: normal;
          line-height: 1;
          flex-shrink: 0;
          user-select: none;
        }

        .jewel-toast__message {
          flex: 1;
          min-width: 0;
          word-break: break-word;
        }

        .jewel-toast__close {
          background: none;
          border: none;
          padding: 0;
          margin: 0;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          opacity: 0.7;
          transition: opacity 150ms ease;
          line-height: 1;
        }

        .jewel-toast__close:hover {
          opacity: 1;
        }

        .jewel-toast__close-icon {
          font-family: 'Material Icons';
          font-size: 16px;
          font-style: normal;
          font-weight: normal;
          line-height: 1;
          user-select: none;
        }
      `,document.head.appendChild(l)}function e(){let l=document.getElementById("jewel-toast-root");return l||(l=document.createElement("div"),l.id="jewel-toast-root",l.setAttribute("role","region"),l.setAttribute("aria-live","polite"),l.setAttribute("aria-label","Notifications"),document.body.appendChild(l)),l}function o(l,r){const a=t[l]||t.info,w="jt-"+Date.now()+"-"+Math.random().toString(36).slice(2,6),u=document.createElement("div");u.id=w,u.className="jewel-toast",u.setAttribute("role","alert"),u.style.backgroundColor=a.bg,u.style.color=a.color;const p=document.createElement("div");p.className="jewel-toast__body";const f=document.createElement("span");f.className="jewel-toast__icon",f.textContent=a.icon,f.style.color=a.color,f.setAttribute("aria-hidden","true");const m=document.createElement("span");m.className="jewel-toast__message",m.textContent=r,p.appendChild(f),p.appendChild(m);const I=document.createElement("button");I.className="jewel-toast__close",I.setAttribute("aria-label","Cerrar notificaci\xF3n"),I.style.color=a.color;const B=document.createElement("span");return B.className="jewel-toast__close-icon",B.textContent="close",B.setAttribute("aria-hidden","true"),I.appendChild(B),u.appendChild(p),u.appendChild(I),{toast:u,id:w,closeBtn:I}}function i(l){const r=document.getElementById(l);r&&(r.classList.add("jewel-toast--exit"),setTimeout(()=>{r.remove();const a=document.getElementById("jewel-toast-root");a&&a.children.length===0&&a.remove()},220))}function s(l,r,a=4e3){n();const w=e(),{toast:u,id:p,closeBtn:f}=o(l,r);w.appendChild(u),requestAnimationFrame(()=>{requestAnimationFrame(()=>{u.classList.add("jewel-toast--visible")})});let m=setTimeout(()=>i(p),a);return u.addEventListener("mouseenter",()=>clearTimeout(m)),u.addEventListener("mouseleave",()=>{m=setTimeout(()=>i(p),1500)}),f.addEventListener("click",()=>{clearTimeout(m),i(p)}),p}return{success:(l,r)=>s("success",l,r),error:(l,r)=>s("error",l,r),warning:(l,r)=>s("warning",l,r),info:(l,r)=>s("info",l,r),dismiss:i}})();function c(){const t=document.querySelector('[data-testid="product-configurator-delivery-selection-card-Recibe a domicilio"]'),n=document.querySelector('[data-testid="product-configurator-delivery-selection-card-Click & Collect"]');if(!t||!n)return null;const e=o=>o.querySelector("span.material-icons")!==null;return e(t)?"home":e(n)?"click-collect":null}async function x(){try{return(await(await fetch(`${BFF}/user/favoriteStore`,{headers:C})).json()).id}catch{return}}async function v(t,n){try{const{variants:e}=await window.jml.getProductById(t),o=e.find(i=>i.skuId===n)?.offers?.bestOffer;return o?{offerId:o.offerId,sellerId:o.sellerId}:void 0}catch{return}}async function N(t,{retryableCodes:n=new Set,successCodes:e=new Set,maxRetries:o=1}={}){for(let i=0;i<=o;i++){const s=await t();if(s.ok)return{status:"success",data:await s.json().catch(()=>null)};const l=await s.json().catch(()=>({}));if(e.has(l.code))return{status:"success"};if(!(n.has(l.code)&&i<o))return{status:"fail",error:l}}}function Q(t){return t!=null&&(t=t.toLowerCase(),t=t.normalize("NFKD"),t=t.replace(/[\u0300-\u036f]/g,""),t=t.replace(/\s+/g,"_")),t}window.jml.wishlistUpdate=jml.debounce(async function(){if(!window.jml.userIsLoggedIn)return;function t(o){const i=document.cookie.match(new RegExp("(^| )"+o+"=([^;]+)"));return i?i[2]:null}if(t("x-cs-folio-id"))return;document.querySelectorAll('[id^="jml-wishlist-button-wrapper"]').forEach(o=>{o.style.display="block"});try{if(window.jml.isStaging){const i=await(await fetch("/web-bff/wishlists/details",{credentials:"include",headers:C})).json();if(i.length===0)return;let s=i.find(({wishlist:l})=>l.isDefault);s||(s=i[0]),window.jml.wishlistId=s.wishlist.id,window.jml.wishlistName=s.wishlist.name,s.items?.forEach(({id:l,wishlistItemId:r})=>{const a=`[id^="jml-wishlist-button-wrapper-${l}"]`;document.querySelectorAll(a).forEach(w=>{w.style.backgroundImage=j,w.classList.add("jewel_added_wishlist"),w.dataset.wishlistItemId=r})})}else{const s=(await(await fetch("/wishListSimpleApigee",{credentials:"include",headers:{accept:"application/json",brand:_,channel:"WEB"}})).json())?.lstWishList;if(!s)return;let l=s.find(({isDefault:r})=>r);l||(l=s[0]),window.jml.wishlistId=l.id,window.jml.wishlistName=l.name,l.lstWishListDetails?.forEach(r=>{const w=`[id^="jml-wishlist-button-wrapper-${r.productId}"]`;document.querySelectorAll(w).forEach(u=>{u.style.backgroundImage=j,u.classList.add("jewel_added_wishlist"),u.dataset.wishlistItemId=r.wishlistProdId})})}}catch{}},250),window.jml.wishlistUpdateUI=(t,n,e)=>{const o=n.split("_")[0],i=document.querySelectorAll(`[id^="jml-wishlist-button-wrapper-${o}"]`),s={wishlisted:j,"not-wishlisted":D,loading:M};i.forEach(l=>{l.style.backgroundImage=s[t],l.style.animation=t==="loading"?"jml-spin 1s linear infinite":"none",t==="wishlisted"?(l.classList.add("jewel_added_wishlist"),e&&(l.dataset.wishlistItemId=e)):t==="not-wishlisted"&&(l.classList.remove("jewel_added_wishlist"),delete l.dataset.wishlistItemId)})},window.jml.newWishlistAdd=async function(t,n,e,o){const i=t.split("_")[0];let s={productId:i,skuId:n};if(e){const r=await v(i,n);r&&(s.sellerId=r.sellerId)}const l=await N(()=>fetch(`/web-bff/wishlists/${window.jml.wishlistId}/add`,{method:"POST",credentials:"include",headers:C,body:JSON.stringify(s)}),{retryableCodes:new Set(["WishlistResponseBadRequestError"]),successCodes:new Set(["WishlistItemAlreadyAddedError"])});if(l.status==="success"){window.jml.wishlistUpdateUI("wishlisted",t,l.data?.wishlistItemId);const r=document.getElementById(`jml-wishlist-button-wrapper-${t}-${o}`);r&&g(r)}else throw new Error("Wishlist add failed")},window.jml.oldWishlistAdd=async function(t,n,e,o){const i=t.split("_")[0];let s={productId:i,skuId:n,wishlistId:window.jml.wishlistId??""};if(e){const r=await window.jml.getProductData(i,n);if(r){const a=r?.mainContent?.records?.at(0)?.allMeta?.variants.find(w=>w?.skuId===n)?.offers?.bestOffer;s.offerId=a?.offerId,s.sellerId=a?.sellerId,s.sellerSapSkuId=a?.sellerSkuId,s.sellerOperatorId=a?.sellerOperatorId}else throw new Error("Item data not found")}const l=await fetch("/addItemToWishlistApigee",{method:"PUT",credentials:"include",headers:{accept:"application/json","content-type":"application/json",brand:_,channel:"WEB"},body:JSON.stringify(s)});if(l.ok){const r=await l.json();window.jml.wishlistUpdateUI("wishlisted",t,r?.productAdded?.wishlistProdId);const a=document.getElementById(`jml-wishlist-button-wrapper-${t}-${o}`);a&&g(a)}else throw new Error("Wishlist add failed")},window.jml.wishlistAdd=async function(t,n,e,o){try{if(!window.jml.wishlistId)return;window.jml.wishlistUpdateUI("loading",t),window.jml.isStaging?await window.jml.newWishlistAdd(t,n,e,o):await window.jml.oldWishlistAdd(t,n,e,o);const i=window.jml.wishlistName||"tu lista";window.jml.isStaging?b.success(`Guardado en ${i}`):jml.showSuccessSnackbar(`Guardado en ${i}`)}catch{window.jml.wishlistUpdateUI("not-wishlisted",t),window.jml.isStaging?b.error("No se pudo agregar a tu lista. Intenta de nuevo."):window.jml.showAlertSnackbar("No se pudo agregar a tu lista. Intenta de nuevo.")}},window.jml.newWishlistRemove=async function(t,n){if((await N(()=>fetch(`/web-bff/wishlists/${window.jml.wishlistId}/items/${n}`,{method:"DELETE",credentials:"include",headers:{"x-brand-id":_}}),{retryableCodes:new Set(["WishlistResponseBadRequestError"]),successCodes:new Set(["WishlistResponseNotFoundError"])})).status==="success")window.jml.wishlistUpdateUI("not-wishlisted",t);else throw new Error("Wishlist remove failed")},window.jml.oldWishlistRemove=async function(t,n){const e=t.split("_")[0],l=(await(await fetch("/wishListSimpleApigee",{credentials:"include",headers:{accept:"application/json",brand:"LP",channel:"WEB"}})).json())?.lstWishList?.[0]?.id;if(!l||!n)throw new Error("Wishlist ID or wishlist product ID not found");if(!(await fetch("/deleteItemToWishlistApigee",{method:"PUT",credentials:"include",headers:{accept:"application/json","content-type":"application/json",brand:_,channel:"WEB"},body:JSON.stringify({wishlistId:l,wishlistProdId:n})})).ok)throw new Error("Wishlist remove failed");window.jml.wishlistUpdateUI("not-wishlisted",t)},window.jml.wishlistRemove=async function(t,n){try{if(!window.jml.wishlistId)return;window.jml.wishlistUpdateUI("loading",t),window.jml.isStaging?await window.jml.newWishlistRemove(t,n):await window.jml.oldWishlistRemove(t,n);const e=window.jml.wishlistName||"tu lista";window.jml.isStaging?b.success(`Eliminaste el producto de ${e} exitosamente.`):jml.showSuccessSnackbar(`Eliminaste el producto de ${e} exitosamente.`)}catch{window.jml.wishlistUpdateUI("wishlisted",t),window.jml.isStaging?b.error("No se pudo eliminar de tu lista. Intenta de nuevo."):window.jml.showAlertSnackbar("No se pudo eliminar de tu lista. Intenta de nuevo.")}},window.jml.wishlistButton=async function(t,n,e,o,i){if(t.preventDefault(),t.stopPropagation(),!window.jml.userIsLoggedIn)return;const s=document.getElementById(`jml-wishlist-button-wrapper-${n}-${e}`);s?.classList.contains("jewel_added_wishlist")?await window.jml.wishlistRemove(n,s.dataset.wishlistItemId):await window.jml.wishlistAdd(n,o,i,e)};async function h(t,n,e){try{const o="/web-bff",i={id:t,sku:n,quantity:jml.cartQuantity};if(c()==="click-collect"&&window.jml.userIsLoggedIn){const r=await x();i.initialAddress={storeId:String(r)}}e&&jml.cart.sellerInfo&&(i.sellerId=jml.cart.sellerInfo.sellerId,i.offerId=jml.cart.sellerInfo.offerId);const s=await fetch(`${o}/cart/items`,{method:"POST",headers:C,body:JSON.stringify(i)});return s.ok?{ok:!0}:{ok:!1,message:(await s.json().catch(()=>null))?.message}}catch{return{ok:!1}}}async function d(t,n,e,o){try{const i={quantity:jml.cartQuantity,catalogRefIds:n,productId:t,productType:o,isEDDCallRequired:"false"};if(e){const r=await window.jml.getProductData(t,n);if(r){const a=r?.mainContent?.records?.at(0)?.allMeta?.variants.find(w=>w?.skuId===n)?.offers?.bestOffer;i.offerId=a?.offerId,i.sellerId=a?.sellerId,i.sellerName=a?.sellerName,i.sellerSkuId=a?.sellerSkuId,i.sellerOperatorId=a?.sellerOperatorId}else throw new Error("Item data not found")}const s=await fetch("/addpdpitemtocart",{method:"POST",credentials:"include",headers:{"content-type":"application/json",accept:"application/json",brand:_,channel:"WEB"},body:JSON.stringify(i)});if(!s.ok)return{ok:!1};const l=await s.json().catch(()=>null);if(l?.formError){const r=Object.keys(l).find(a=>/^\d+$/.test(a)&&l[a]?.err);return{ok:!1,message:r?l[r].err:void 0}}return{ok:!0}}catch(i){return jml.errors=jml.errors??[],jml.errors.push(i.message),{ok:!1}}}window.jml.addToCart=async function(t,n,e,o,i,s){t.preventDefault(),t.stopPropagation();try{const l=n.split("_")[0];let r={ok:!1};if(window.jml.isStaging?r=await h(l,e,i):r=await d(l,e,i,s??"Soft Line"),!r.ok){const p="Ocurri\xF3 un error al agregar a tu bolsa.";return window.jml.isStaging?b.error(r.message||p):window.jml.showAlertSnackbar(r.message||p),r}window.jml.isStaging?b.success(`Agregaste ${window.jml.cartQuantity} art\xEDculo(s) a tu bolsa.`):window.jml.showSuccessSnackbar(`Agregaste ${window.jml.cartQuantity} art\xEDculo(s) a tu bolsa.`);const a=document.getElementById(`jml-addToCart-button-wrapper-${n}-${o}`),w=document.getElementById(`jml-mobileAddtoCart-button-wrapper-${n}-${o}`);a&&y(a),w&&y(w);const u=document.querySelector(`.jml-item-size-${e}-${o}`);if(u){const p=u.innerText;u.style.transition="all 0.25s ease-in-out",u.innerText="\u2714",setTimeout(()=>{u.innerText=p,u.style.transition="none"},1e3)}if(window.jml.isStaging){const p=document.querySelectorAll('[data-testid$="header-cart-quantity"]');p.length===0?document.querySelectorAll('[data-testid$="header-shopping-cart-shopping-link"]').forEach(f=>{const m=document.createElement("div");m.className="flex items-center justify-center w-[23px] h-[23px] text-body-sm font-semibold rounded-full bg-icon-alert text-header-icon absolute top-5 left-6",m.setAttribute("data-testid","bltc47588223af88ea0-header-shopping-cart-header-cart-quantity"),m.textContent="1",f.style.position="relative",f.appendChild(m)}):p.forEach(f=>{if(!f.textContent.includes("+")){const m=parseInt(f.textContent)+1;f.textContent=m>9?"9+":String(m)}})}else{const p=document.querySelectorAll(".a-header__bag>span");if(p.length===0){const f=document.createElement("span");f.innerText="1",document.querySelector(".a-header__bag").appendChild(f)}else if(!p[0].innerText.includes("+")){const f=parseInt(p[0].innerText)+1;f>9?p[0].innerText="9+":p[0].innerText=f}}return r}catch{return{ok:!1}}},window.jml.selectMobileCartSize=function(t,n){t.preventDefault(),t.stopPropagation();const e=jml.sizeOptions[parseInt(n)];window.jml.cart={size:e.size,offerId:jml.selectedProduct.productId,itemVariantId:e.skuId,unique:jml.selectedUnique,isMarketplace:e.isMarketplace,articleType:jml.selectedProduct.productType,sellerInfo:e.offers?.bestOffer},window.jml.updateCartUI({action:"size-changed"})},window.jml.addToCartMobile=async function(t,n){if(!window.jml.cart){window.jml.isStaging?b.warning("Por favor, selecciona una opci\xF3n"):window.jml.showAlertSnackbar("Por favor, selecciona una opci\xF3n");return}try{const e=document.getElementById("jml-mobile-cart-confirm-button-text"),o=document.getElementById("jml-mobile-cart-confirm-button-loading");e.style.display="none",o.style.display="block";const i=await window.jml.addToCart(t,jml.selectedOfferId,window.jml.cart.itemVariantId,window.jml.cart.unique,window.jml.cart.isMarketplace,window.jml.cart.articleType);e.style.display="block",o.style.display="none",i?.ok&&(n?window.jml.closeModalDesktop():window.jml.closeModalMobile())}catch{}},window.jml.sortSizes=t=>{const n=["Short","Regular","Long"],e=["2XCH","XXCH","XCH","CH","P","M","G","XG","2XG","XXG","3XG","XXXG","XXL","Est\xE1ndar","Euro","King","Matrimonial","Queen"],o=["32GB","32 GB","64GB","64 GB","128GB","128 GB","256GB","256 GB","512GB","512 GB","1TB","1 TB","2TB","2 TB","3TB","3 TB","4TB","4 TB","5TB","5 TB"],i=(s,l)=>s<l?-1:s>l?1:0;return[...t].sort((s,l)=>{const r=s.size,a=l.size;if(!r||!a)return 0;const w=r.split(" "),u=a.split(" "),p=w[0],f=u[0];if(o.includes(r)&&o.includes(a))return i(o.indexOf(r),o.indexOf(a));if(e.includes(p)&&e.includes(f))return i(e.indexOf(p),e.indexOf(f));const m=Number(p),I=Number(f);if(Number.isFinite(m)&&Number.isFinite(I)&&p!==""&&f!=="")return i(m,I);if(w.length>1&&u.length>1){const B=w[1],G=u[1];return n.includes(B)&&n.includes(G)?i(n.indexOf(B),n.indexOf(G)):i(r,a)}return i(r,a)})},window.jml.getVariantsInfo=async function(t,n){try{if(window.jml.isStaging){const{variants:m,colorSet:I,smallImage:B,id:G,productType:ee,brand:te,title:ne}=await fetch(`/web-bff/product/${t}`).then(W=>W.json()),J=m.map(W=>({...W,isMarketplace:!!W.bestOfferSellerName})),V=J.every(W=>!W.colorName),Z=V?[]:I,oe=V?[[...J]]:Z.map(({colorName:W})=>J.filter(X=>X.colorName.toLowerCase()===W.toLowerCase()||X.clothingBrandColor?.toLowerCase()===W.toLowerCase()));return{colorSet:Z,variantsByColor:oe,variants:J,defaultImage:B,productId:G,productType:ee,brand:te,title:ne,hasColor:!V}}const e=await fetch(`/tienda/oneColumnPageData?productId=${t}&pdpType=default${n?`&skuId=${n}`:""}`,{headers:{accept:"application/json, text/plain, */*",brand:_,channel:"WEB"}}).then(m=>m.json()),{variants:o,id:i,productImages:s,productType:l,brand:r,title:a}=e.mainContent.records[0].allMeta,w=o.map(m=>({skuId:m.skuId,colorName:m.color,clothingBrandColor:m.clothingBrandColor,colorHex:m.colorhex,smallImage:m.smallImage,size:m.size,title:m.skuName,isMarketplace:m.sellernames.some(I=>I.toLowerCase()!=="liverpool")})),u=w.every(m=>!m.colorName),p=u?[]:w.map(({clothingBrandColor:m,colorName:I,colorHex:B})=>({colorName:m??I,colorHex:B})).reduce((m,I)=>(m.find(({colorHex:G})=>G===I.colorHex)||m.push(I),m),[]),f=u?[[...w]]:p.map(({colorName:m})=>w.filter(I=>I.colorName.toLowerCase()===m.toLowerCase()||I.clothingBrandColor?.toLowerCase()===m.toLowerCase()));return{colorSet:p,variantsByColor:f,variants:w,productId:i,defaultImage:s[0].imageUrl,productType:l,brand:r,title:a,hasColor:!u}}catch(e){return jml.variantsError=e.stack,null}},window.jml.selectMobileCartColor=(t,n)=>{jml.selectedColor=parseInt(n),jml.cart=null,jml.sizeOptions=jml.sortSizes(jml.selectedProduct.variantsByColor[jml.selectedColor]),jml.hasSizes=jml.sizeOptions.find(e=>!!e.size)??!1,jml.hasSizes||window.jml.selectMobileCartSize(t,0),window.jml.updateCartUI({action:"color-changed"})},window.jml.buildColorPicker=()=>jml.selectedProduct.colorSet.map(({colorName:t,clothingBrandColor:n},e)=>`<button
        onclick="window.jml.selectMobileCartColor(event, '${e}');"
        style="padding:0px;outline:none;background-color:transparent;display:flex;flex-direction:column;align-items:center;justify-content:center;border:0px;"
      >
        <div style="background-color:transparent;position:relative;${e===jml.selectedColor?"border-radius:4px;border:1px solid #E10098":"border-radius:4px;border:1px solid transparent"};display:flex;flex-direction:column;align-items:center;justify-content:center;width:60px;height:78px;">
          <img src="${jml.selectedProduct.variantsByColor[e]?.at(0)?.smallImage??jml.selectedProduct.defaultImage}" style="width:100%;"></img>
          ${e===jml.selectedColor?`<div style="position:absolute;top:-12px;right:-8px">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M0 7C0 3.13401 3.13401 0 7 0C10.866 0 14 3.13401 14 7C14 10.866 10.866 14 7 14C3.13401 14 0 10.866 0 7Z" fill="#E10098"/>
              <path fill-rule="evenodd" clip-rule="evenodd" d="M9.85355 4.93551C10.0488 5.13077 10.0488 5.44735 9.85355 5.64262L6.28571 9.21045L4.14645 7.07119C3.95118 6.87593 3.95118 6.55934 4.14645 6.36408C4.34171 6.16882 4.65829 6.16882 4.85355 6.36408L6.28571 7.79624L9.14645 4.93551C9.34171 4.74025 9.65829 4.74025 9.85355 4.93551Z" fill="white"/>
            </svg>
          </div>`:""}
        </div>
        <p style="font-size:12px;margin:4px 0px 0px;color:${e===jml.selectedColor?"#333333":"#767676"};width:60px;">${n??t}</p>
      </button>`).join(""),window.jml.buildSizePicker=()=>jml.sizeOptions.map((t,n)=>`<button onclick="window.jml.selectMobileCartSize(event, '${n}');" 
        class="jewel-modal-product-button ${t.skuId===window.jml.cart?.itemVariantId?"jewel-modal-product-button-selected":""}">${t.size}</button>
        `).join(""),window.jml.buildQuantityPicker=()=>`
      <p style="font-family:robotomedium, Roboto-Medium;font-size:14px;margin:0px;">Cantidad:</p>
      <div style="display:flex;gap:8px;">
        <button onclick="window.jml.decrementQuantity()" style="outline:none;width:40px;height:40px;background-color:#F5F5F5;border:1px solid #C0C0C0;border-radius:4px;${jml.cartQuantity===1?"color:#C0C0C0":""}">-</button/>
        <p style="margin:0px;height:40px;width:64px;background-color:transparent;border:1px solid #C0C0C0;border-radius:4px;text-align:center;line-height:40px;">${jml.cartQuantity}</p>
        <button onclick="window.jml.incrementQuantity()" style="outline:none;width:40px;height:40px;background-color:#F5F5F5;border:1px solid #C0C0C0;border-radius:4px;">+</button/>
      </div>`,window.jml.incrementQuantity=()=>{jml.cartQuantity+=1;const t=document.getElementById("jml-mobile-cart-quantity-picker");t.innerHTML=window.jml.buildQuantityPicker()},window.jml.decrementQuantity=()=>{if(jml.cartQuantity>1){jml.cartQuantity-=1;const t=document.getElementById("jml-mobile-cart-quantity-picker");t.innerHTML=window.jml.buildQuantityPicker()}},window.jml.updateCartUI=({action:t})=>{if(t==="color-changed"&&jml.selectedProduct.hasColor){const n=document.getElementById("jml-mobile-cart-selected-color");n.innerText=jml.selectedProduct.colorSet[jml.selectedColor].colorName;const e=document.getElementById("jml-mobile-cart-color-pickers");e.innerHTML=window.jml.buildColorPicker();const o=document.getElementById("jml-mobile-cart-main-image");o.src=jml.sizeOptions?.at(0)?.smallImage??jml.selectedProduct.defaultImage}if(jml.hasSizes){const n=document.getElementById("jml-mobile-cart-selected-size");n.innerText=window.jml?.cart?.size??"Selecciona una opci\xF3n";const e=document.getElementById("jml-mobile-cart-size-pickers");e.innerHTML=window.jml.buildSizePicker()}},window.jml.buildImageSkeleton=()=>`
    <div class="jml-skeleton" style="width: 80px; height: 104px;"></div>
  `,window.jml.buildImage=(t,n)=>`
    <img id="jml-mobile-cart-main-image" src="${t}" alt="${n}" style="width: 80px; height: 104px; object-fit: contain; border-radius: 4px;">
  `,window.jml.buildMetaSkeleton=()=>`
    <div style="display: flex; flex-direction: column; gap: 8px; padding-top: 4px;">
      <div class="jml-skeleton" style="width: 90px; height: 16px;"></div>
      <div class="jml-skeleton" style="width: 180px; height: 16px;"></div>
      <div class="jml-skeleton" style="width: 140px; height: 16px;"></div>
    </div>
  `,window.jml.buildMeta=(t,n)=>`
    <p style="margin-bottom: 0px; font-size: 16px; font-weight: 600; color: #000; line-height: 20.8px; font-family: 'robotoRegular', sans-serif;">${t}</p>
    <p style="margin-bottom: 0px; font-size: 16px; font-weight: 400; color: #000; line-height: 20.8px; font-family: 'robotoRegular', sans-serif;">${n}</p>
  `,window.jml.buildOptionsSkeleton=()=>`
    <div class="jml-skeleton" style="display:block;height: 48px; margin: 24px 0 16px 0; border-radius: 8px;"></div>
    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
      <div class="jml-skeleton" style="width: 60px; height: 78px;"></div>
      <div class="jml-skeleton" style="width: 60px; height: 78px;"></div>
      <div class="jml-skeleton" style="width: 60px; height: 78px;"></div>
      <div class="jml-skeleton" style="width: 60px; height: 78px;"></div>
    </div>
    <div class="jml-skeleton" style="display:block;height: 48px; margin: 24px 0 16px 0; border-radius: 8px;"></div>
    <div style="display: flex; flex-wrap: wrap; gap: 8px 12px;">
      <div class="jml-skeleton" style="width: 64px; height: 40px;"></div>
      <div class="jml-skeleton" style="width: 64px; height: 40px;"></div>
      <div class="jml-skeleton" style="width: 64px; height: 40px;"></div>
      <div class="jml-skeleton" style="width: 64px; height: 40px;"></div>
      <div class="jml-skeleton" style="width: 64px; height: 40px;"></div>
    </div>
  `,window.jml.buildOptions=()=>{const t=jml.selectedProduct.hasColor?`
      <div style="background-color: #f5f5f5; padding: 8px; border-radius: 8px; height: 48px; display: flex; flex-direction: row; gap: 4px; align-items: center; margin: 24px 0 16px 0;">
        <p style="margin: 0; font-size: 14px; font-weight: 600; color: #333333;">Color:</p>
        <p id="jml-mobile-cart-selected-color" style="margin: 0; font-size: 14px; font-weight: 400; color: #333333;">${jml.selectedProduct.colorSet[jml.selectedColor].colorName}</p>
      </div>
      <div id="jml-mobile-cart-color-pickers" style="display: flex; gap: 8px; align-items: start;flex-wrap:wrap">
        ${window.jml.buildColorPicker()}
      </div>
    `:"",n=jml.hasSizes?`
      <div id="jml-mobile-cart-size-container">
        <div style="background-color: #f5f5f5; padding: 8px; border-radius: 8px; height: 48px; display: flex; flex-direction: row; gap: 4px; align-items: center; margin: 24px 0 16px 0;">
          <p style="margin: 0; font-size: 14px; font-weight: 600; color: #333333;">Talla:</p>
          <p id="jml-mobile-cart-selected-size" style="margin: 0; font-size: 14px; font-weight: 400; color: #333333;">Selecciona una opci\xF3n</p>
        </div>
        <div id="jml-mobile-cart-size-pickers" style="display: flex; flex-wrap: wrap; gap: 8px 12px;">
          ${window.jml.buildSizePicker()}
        </div>
      </div>
    `:"";return t+n},window.jml.populateModalContent=(t,n,e)=>{const o=document.getElementById("jml-cart-image-wrapper"),i=document.getElementById("jml-cart-product-meta"),s=document.getElementById("jml-cart-options"),l=document.getElementById("jml-mobile-cart-confirm-button");if(!o||!i||!s)return;if(!jml.selectedProduct){i.innerHTML='<p style="color:#b50000;font-size:14px;margin:0;padding:8px 0;">No se pudo cargar la informaci\xF3n del producto.</p>',s.innerHTML="";return}const r=jml.selectedProduct.variants.find(({skuId:p})=>n===p)??jml.selectedProduct.variants[0];if(jml.selectedColor=jml.selectedProduct.hasColor?jml.selectedProduct.colorSet.findIndex(({colorName:p})=>r.colorName.toLowerCase()===p.toLowerCase()||r.clothingBrandColor?.toLowerCase()===p.toLowerCase()):0,jml.selectedColor===-1&&(jml.selectedColor=0),jml.sizeOptions=jml.sortSizes(jml.selectedProduct.variantsByColor[jml.selectedColor]),jml.hasSizes=jml.sizeOptions.find(p=>!!p.size)??!1,!jml.hasSizes){if(!jml.sizeOptions.at(0)){i.innerHTML='<p style="color:#b50000;font-size:14px;margin:0;padding:8px 0;">No se pudo cargar la informaci\xF3n del producto.</p>',s.innerHTML="";return}window.jml.selectMobileCartSize(t,0)}const a=jml.sizeOptions?.at(0)?.smallImage??jml.selectedProduct.defaultImage,w=jml.selectedProduct.title,u=jml.selectedProduct.brand;o.innerHTML=window.jml.buildImage(a,w),i.innerHTML=window.jml.buildMeta(u,w),s.innerHTML=window.jml.buildOptions(),l&&l.removeAttribute("disabled")},window.jml.openModalMobile=async function(t,n,e,o){t.preventDefault(),t.stopPropagation();try{document.querySelector("html").classList.add("noscroll"),window.jml.cart=null,jml.selectedProduct=null,jml.sizeOptions=null,jml.selectedUnique=o,jml.selectedOfferId=n,jml.cartQuantity=1;const s=n.split("_").length>1?n.split("_")[0]:n,l=`<div id="jml-mobile-modal" role="presentation" data-testid="base-modal" style="position: fixed; inset: 0px; z-index: 999999;">
        <div tabindex="-1" class="jml-mobile-modal">
          <div class="jewel-modal-content">
            <div class="jewel-modal-product">
              <div class="jewel-modal-product-header">
                <p class="jewel-modal-product-title" style="font-family:robotomedium, Roboto-Medium;">Selecciona una opci\xF3n</p>
                <div class="jewel-modal-product-close-button" onclick="window.jml.closeModalMobile()">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="#333333"/>
                  </svg>
                </div>
              </div>
              <div class="jewel-modal-product-content">
                <div style="padding: 16px 16px 24px 16px;overflow-y:auto;max-height: 75svh;">
                  <div style="display: flex; flex-direction: row; gap: 16px;">
                    <div id="jml-cart-image-wrapper" style="flex: 0 0 80px;">
                      ${window.jml.buildImageSkeleton()}
                    </div>
                    <div id="jml-cart-product-meta" style="display: flex; flex-direction: column; flex: 1; min-width: 0;">
                      ${window.jml.buildMetaSkeleton()}
                    </div>
                  </div>
                  <div id="jml-cart-options">
                    ${window.jml.buildOptionsSkeleton()}
                  </div>
                  <div id="jml-mobile-cart-quantity-picker" style="margin-top:24px;display:flex;justify-content:space-between;align-items:center;">
                    ${window.jml.buildQuantityPicker()}
                  </div>
                </div>
                <div style="padding: 16px 16px 24px 16px; border-top: 1px solid #f5f5f5;">
                  <button id="jml-mobile-cart-confirm-button" class="jewel-modal-confirm-button" onclick="window.jml.addToCartMobile(event,false)" disabled style="display:flex;align-items:center;justify-content:center;">
                    <p id="jml-mobile-cart-confirm-button-text" style="margin: 0;">Agregar a mi bolsa</p>
                    <div id="jml-mobile-cart-confirm-button-loading" style="display: none;" class="jml-loading-animation">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      >
                        <path d="M21 12a9 9 0 11-6.219-8.56" />
                      </svg>
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div onclick="window.jml.closeModalMobile()" class="jewel-modal-backdrop-container" data-testid="modal-backdrop-container" style="animation: show-jml-modal-backdrop 0.3s ease-in-out;">
          <div role="presentation" class="jewel-modal-backdrop"></div>
        </div>
      </div>`;document.body.appendChild(document.createRange().createContextualFragment(l));try{const r=document.getElementById(`jml-mobileAddtoCart-button-wrapper-${n}-${o}`);jml.pageModel=$(r),window.dataLayer.push({event:"jewel_pdp_view",jml_page:window.location.pathname,jml_query:window.location.search,jewel_model_name:jml.pageModel})}catch{}if(jml.selectedProduct=await window.jml.getVariantsInfo(s,n),!document.getElementById("jml-mobile-modal"))return;window.jml.populateModalContent(t,e,!1)}catch(i){window.jml.fail=i.stack}},window.jml.closeModalMobile=function(){document.querySelector("html").classList.remove("noscroll");const n=document.getElementById("jml-mobile-modal"),e=document.querySelector(".jewel-modal-backdrop-container"),o=document.querySelector(".jewel-modal-content");n&&(o.style.animation="hide-jml-modal 0.3s ease-in-out",e.style.animation="hide-jml-modal-backdrop 0.3s ease-in-out",n.addEventListener("animationend",()=>n.remove())),jml.pageModel=null},window.jml.openModalDesktop=async function(t,n,e,o){t.preventDefault(),t.stopPropagation(),jml.fail=void 0;try{document.querySelector("html").classList.add("noscroll"),window.jml.cart=null,jml.selectedProduct=null,jml.sizeOptions=null,jml.selectedUnique=o,jml.selectedOfferId=n,jml.cartQuantity=1;const s=n.split("_").length>1?n.split("_")[0]:n,l=`<div id="jml-mobile-modal" role="presentation" data-testid="base-modal" style="position: fixed; inset: 0px; z-index: 999999;">
        <div tabindex="-1" class="jml-mobile-modal">
          <div class="jewel-modal-content" style="animation: show-jml-modal-desktop 0.3s ease-in-out;">
            <div class="jewel-modal-product">
              <div class="jewel-modal-product-header">
                <p class="jewel-modal-product-title" style="font-family:robotomedium, Roboto-Medium;">Selecciona una opci\xF3n</p>
                <div class="jewel-modal-product-close-button" onclick="window.jml.closeModalDesktop()">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="#333333"/>
                  </svg>
                </div>
              </div>
              <div class="jewel-modal-product-content">
                <div style="padding: 16px 16px 0px 16px;overflow-y:auto;max-height: calc(100svh - 137px);">
                  <div style="display: flex; flex-direction: row; gap: 16px;">
                    <div id="jml-cart-image-wrapper" style="flex: 0 0 80px;">
                      ${window.jml.buildImageSkeleton()}
                    </div>
                    <div style="display: flex; flex-direction: column; flex: 1; min-width: 0;">
                      <div id="jml-cart-product-meta">
                        ${window.jml.buildMetaSkeleton()}
                      </div>
                      <div>
                        <div id="jml-cart-options">
                          ${window.jml.buildOptionsSkeleton()}
                        </div>
                        <div id="jml-mobile-cart-quantity-picker" style="margin-top:24px;display:flex;justify-content:space-between;align-items:center;">
                          ${window.jml.buildQuantityPicker()}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div style="height:1px;width:100%;border-bottom: 1px solid #D8D8D8;padding:32px 16px 24px 16px"></div>
                </div>
                <div style="padding: 16px 16px 24px 16px;">
                  <button id="jml-mobile-cart-confirm-button" class="jewel-modal-confirm-button" onclick="window.jml.addToCartMobile(event,true)" disabled style="display:flex;align-items:center;justify-content:center;">
                    <p id="jml-mobile-cart-confirm-button-text" style="margin: 0;">Agregar a mi bolsa</p>
                    <div id="jml-mobile-cart-confirm-button-loading" style="display: none;" class="jml-loading-animation">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      >
                        <path d="M21 12a9 9 0 11-6.219-8.56" />
                      </svg>
                    </div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div onclick="window.jml.closeModalDesktop()" class="jewel-modal-backdrop-container" data-testid="modal-backdrop-container" style="animation: show-jml-modal-backdrop 0.3s ease-in-out;">
          <div role="presentation" class="jewel-modal-backdrop"></div>
        </div>
      </div>`;document.body.appendChild(document.createRange().createContextualFragment(l));try{const r=document.getElementById(`jml-mobileAddtoCart-button-wrapper-${n}-${o}`);jml.pageModel=$(r),window.dataLayer.push({event:"jewel_pdp_view",jml_page:window.location.pathname,jml_query:window.location.search,jewel_model_name:jml.pageModel})}catch{}if(jml.selectedProduct=await window.jml.getVariantsInfo(s,n),!document.getElementById("jml-mobile-modal"))return;window.jml.populateModalContent(t,e,!0)}catch(i){window.jml.fail=i.stack}},window.jml.closeModalDesktop=function(){document.querySelector("html").classList.remove("noscroll");const n=document.getElementById("jml-mobile-modal"),e=document.querySelector(".jewel-modal-backdrop-container"),o=document.querySelector(".jewel-modal-content");n&&(o.style.animation="hide-jml-modal-desktop 0.3s ease-in-out",e.style.animation="hide-jml-modal-backdrop 0.3s ease-in-out",n.addEventListener("animationend",()=>n.remove())),jml.pageModel=null};function y(t){const{itemName:n,modelName:e,offerId:o}=k(t);window.dataLayer.push({event:"jewel_cart_click",jewel_item_name:n,jewel_model_name:e,jewel_offer_id:o,model:e,value:n})}function g(t){const{itemName:n,modelName:e,offerId:o}=k(t);window.dataLayer.push({event:"jewel_favorite_click",jewel_item_name:n,jewel_model_name:e,jewel_offer_id:o,model:e,value:n})}function k(t){if(t){let n=T(t,["_jml_grid_item","_jml_carousel_slide"]),[e,o,i]=z(n);return{itemName:e,modelName:o,offerId:i}}}function $(t){if(t){let n=T(t,["_jml_grid_item","_jml_carousel_slide"]),[e,o,i]=z(n);return o}}function T(t,n){let e=t.parentElement;for(;e;){for(let o of n)if(e.classList.contains(o))return e;e=e.parentElement}return null}function E(t,n){let e=t.parentElement;for(;e;){if(e.classList.contains(n))return e;e=e.parentElement}return null}function z(t){let n=t.querySelector("._jml_section_item_link_css").innerText.trim(),e=t.querySelector("[data-jmlmodel]"),o=e.getAttribute("data-jmlmodel").trim(),i=e.getAttribute("offer-id").trim();return[n,o,i]}})();try{var H=typeof window.__jml_custom_function=="function"?window.__jml_custom_function():window.__jml_custom_function;if(H===!1){window.jml={};return}}catch(_){console.warn("jml custom_selector_function threw",_)}window.jml={...window.jmlrc,...window.jml,version:"2.3.8",currentUrl:window.location.href,carouselRendered:!1,noRecs:!1,tries:0,maxTries:3,enable_reload:!1,serviceDown:!1,renderInProgress:!1,rendered:0,shouldRender:0,user:window.__jmlt&&window.__jmlt.s?window.__jmlt.s():{},item_url:window.location.pathname,pathToRegex:function(R){const O=/[\[\]\(\)\.\+\*\?\|]/.test(R),U=R.replace(/\\\//g,"/");return O&&!R.includes(":")?new RegExp(U):new RegExp("^"+R.replace(/\/:\w+\(\.\+\)/g,"/(.+)").replace(/:\w+/g,"[^/]+").replace(/\//g,"\\/")+"$")},catalogPath:"https://repersonalize.jewelml.io/c/p/67fd95260740ccc4ec658d03/l",batchPath:"https://repersonalize.jewelml.io/c/p/67fd95260740ccc4ec658d03/b",enable_unified_cache:!0,routesObject:{},layoutSectionsMap:{},enableLazyHydration:!0,url_homepage:"https://www.liverpool.com.mx",integration_id:"67fd95260740ccc4ec658d03",algolia_client_properties:null,debug_mode:window.sessionStorage.getItem("__jml_debug_mode")||!1,enable_deduplicate:!0,max_deduplicate_items:0,dynamic_carousel_load:!1,max_carousel_load:0,personalizedSavedModels:["GP_prod","LM_prod","RA1_prod","RA2_prod","RA3_prod","RA4_prod"],item_id_function:`(() => {
  function normalizeString(value) {
    if (value !== null && value !== undefined) {
      value = value.toLowerCase();
      value = value.normalize('NFKD');
      value = value.replace(/[\\u0300-\\u036f]/g, '');
      value = value.replace(/\\s+/g, '_');
    }
    return value;
  }

  function getStagingItemId() {
    // --- Approach 1: RSC __next_f ---
    // Works correctly on hard nav / first load (when 'c' root is fresh).
    // On PDP\u2192PDP SPA navigation, 'c' stays stale (first page ever loaded),
    // so the result is validated against the current URL before being trusted.
    function tryRSC() {
      const chunks = window.__next_f
        .filter(x => Array.isArray(x) && x[0] === 1 && typeof x[1] === 'string')
        .map(x => x[1]);

      for (const s of document.querySelectorAll('script')) {
        let m, re = /__next_f\\.push\\(\\[(\\d+),(.*)\\]\\s*\\)/gs;
        while ((m = re.exec(s.textContent)) !== null)
          if (parseInt(m[1]) === 1)
            try { const p = JSON.parse(m[2]); if (typeof p === 'string') chunks.push(p); } catch {}
      }

      const fullText = chunks.join('');
      const rows = new Map();
      let i = 0;
      while (i < fullText.length) {
        const ci = fullText.indexOf(':', i); if (ci === -1) break;
        const id = fullText.substring(i, ci);
        if (!/^[0-9a-f]+$/i.test(id)) { const nl = fullText.indexOf('\\n', i); i = nl < 0 ? fullText.length : nl + 1; continue; }
        const nl = fullText.indexOf('\\n', ci + 1);
        rows.set(id, nl < 0 ? fullText.substring(ci + 1) : fullText.substring(ci + 1, nl));
        i = nl < 0 ? fullText.length : nl + 1;
      }

      const parsed = new Map();
      const JS = new Set(['{', '[', '"', "'", '-', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 't', 'f', 'n']);
      for (const [id, raw] of rows)
        try { parsed.set(id, JS.has(raw[0]) ? JSON.parse(raw) : raw); } catch { parsed.set(id, raw); }

      function isProduct(o) {
        return o && typeof o === 'object' && !Array.isArray(o)
          && typeof o.maximumListPrice === 'number' && typeof o.minimumPromoPrice === 'number'
          && Array.isArray(o.sizeSet)
          && Array.isArray(o.variants) && o.variants.length > 0 && o.variants[0] !== null
          && Array.isArray(o.colorSet);
      }

      function find(node, seen = new WeakSet(), d = 0) {
        if (d > 80 || node == null) return null;
        if (typeof node === 'string') {
          if (node.startsWith('$') && !node.startsWith('$L')) {
            const r = parsed.get(node.slice(1)); if (r != null) return find(r, seen, d + 1);
          }
          return null;
        }
        if (typeof node !== 'object' || seen.has(node)) return null;
        seen.add(node);
        if (isProduct(node)) return node;
        for (const c of (Array.isArray(node) ? node : Object.values(node))) {
          const f = find(c, seen, d + 1); if (f) return f;
        }
        return null;
      }

      const p = find(parsed.get('c'));
      if (!p) return null;

      const urlSku = new URLSearchParams(window.location.search).get('skuid');
      const variants = p.variants.map(v => ({ skuId: v.skuId, colorName: v.colorName ?? null }));
      return {
        id: p.id,
        hasColor: p.colorSet.length > 0,
        selectedVariant: variants.find(v => v.skuId === urlSku) ?? variants[0] ?? null,
      };
    }

    // --- Approach 2: React Fiber ---
    // Always reflects the live rendered page state.
    // Used as fallback when RSC returns stale data (PDP\u2192PDP SPA navigation).
    function tryFiber() {
      const heading = document.querySelector('h1');
      if (!heading) return null;

      const fiberKey = Object.keys(heading).find(k => k.startsWith('__reactFiber'));
      if (!fiberKey) return null;

      let current = heading[fiberKey];
      while (current) {
        const props = current.memoizedProps;
        if (props && props.product && typeof props.product.id !== 'undefined') {
          const p = props.product;
          const urlSku = new URLSearchParams(window.location.search).get('skuid');
          const variants = (p.variants || [])
            .filter(v => v)
            .map(v => ({ skuId: v.skuId, colorName: v.colorName ?? null }));
          return {
            id: p.id,
            hasColor: Array.isArray(p.colorSet) && p.colorSet.length > 0,
            selectedVariant: variants.find(v => v.skuId === urlSku) ?? variants[0] ?? null,
          };
        }
        current = current.return;
      }
      return null;
    }

    // Validate RSC result against the current URL's product ID.
    // If they don't match, RSC data is stale \u2192 fall back to fiber.
    const currentProductId = window.location.pathname.split('/').filter(Boolean).pop();

    const rscResult = tryRSC();
    if (rscResult && rscResult.id === currentProductId) return rscResult;

    const fiberResult = tryFiber();
    if (fiberResult) return fiberResult;

    // Last resort: return RSC result even if unvalidated
    if (rscResult) return rscResult;

    throw new Error('Product not found');
  }

  function getMainColorFromNext(allMeta, currentSKUPDPColor) {
    if (!allMeta) {
      return {
        color: undefined,
        productId: undefined
      }
    }

    const variants = allMeta?.variants
    const currentVariantIndex = variants.findIndex(item => {
      if (item.clothingBrandColor) {
         return normalizeString(item.clothingBrandColor) === normalizeString(currentSKUPDPColor)
      }
      return normalizeString(item.color) === normalizeString(currentSKUPDPColor)
    })

    // If not find an index will return -1
    const validVariantIndex = currentVariantIndex < 0 ? 0 : currentVariantIndex

    const color = variants[validVariantIndex]?.color

    return color
  }

  function getMainColorFromElements() {
    let color = undefined
    
    const isColor = document.querySelector('.attributeAccordionText')?.innerText.includes('Color'); 

    if (isColor) {
      color = document.querySelector('.attributeAccordionTextValue')?.textContent?.trim()
    }

    return {
      elementColor: color
    }
  }

  function getMainColor() {
    jml.logs = jml.logs ?? []
    const { elementColor } = getMainColorFromElements()


    if (!elementColor) {
      return undefined
    }

    if (window.next.router.components['/tienda/oneColumnPage'].props.pageProps.initialPropsData) {
      return getMainColorFromNext(window.next.router.components['/tienda/oneColumnPage'].props.pageProps.initialPropsData.mainContent.records[0].allMeta, elementColor)
    }

    const rawData = JSON.parse(document.querySelector("#__NEXT_DATA__")?.innerText)
    
    return getMainColorFromNext(rawData.query?.data?.mainContent?.records?.at(0)?.allMeta, elementColor)
  }
  
  try {
    if (window?.jml?.isStaging) {
      const stagingProduct = getStagingItemId()

      if (!stagingProduct) {
        return "empty"
      }

      if (stagingProduct.hasColor) {
        const color = normalizeString(stagingProduct.selectedVariant.colorName)

        return \`\${stagingProduct.id}_\${color}\`
      }

      return stagingProduct.id
    }

    let productId = window.location.pathname.split("/").pop()
    if (!productId) return 'empty';

    let color = getMainColor()

    if (!color) {
      return productId
    }

    color = normalizeString(color)

    return \`\${productId}_\${color}\`
  } catch (error) {
    return "empty"
  }
})()`,observers:new Map,Swiper:window.Swiper},(()=>{function _(O){return O.replace(/\//g,"/")}if(Object.keys(jml.routesObject).filter(O=>O!=="/").some(O=>{try{return jml.pathToRegex(_(O)).test(location.pathname)}catch(U){return console.warn("Invalid pattern:",O,U),!1}})&&window.jml.item_id&&window.jml.item_id!=="undefined"&&window.jml.item_id!=="null"&&window.location.pathname!=="/"){const O=localStorage.getItem("jml_recently_viewed_items_67fd95260740ccc4ec658d03"),U=O?O.split(","):[],q=window.jml.item_id==="empty"?encodeURIComponent(window.jml.item_url):window.jml.item_id;let S="";if(U.length===0)S=q.toString();else{const P=U.filter(F=>F!==q.toString());P.unshift(q),S=P.slice(0,20).join(",")}localStorage.setItem("jml_recently_viewed_items_67fd95260740ccc4ec658d03",S)}})(),setTimeout(function(){function _(A,L){let j;return function(...M){clearTimeout(j),j=setTimeout(()=>A.apply(this,M),L)}}function R(){window.jml||(window.jml={}),window.jml.observers||(window.jml.observers=new Map)}function O(A,L=document.body){R();let j;const M=L||document.body||document.documentElement;if(!M)return;if(window.jml.observers.has(M))return window.jml.observers.get(M);const D=new MutationObserver(C=>{jml.debug().log("r.js mutation"),document.querySelectorAll("div[id$='jml-carousel']").length==0&&(jml.carouselRendered=!1);try{let b=(()=>{function c(h){return h!=null&&(h=h.toLowerCase(),h=h.normalize("NFKD"),h=h.replace(/[\u0300-\u036f]/g,""),h=h.replace(/\s+/g,"_")),h}function x(){function h(){const $=window.__next_f.filter(r=>Array.isArray(r)&&r[0]===1&&typeof r[1]=="string").map(r=>r[1]);for(const r of document.querySelectorAll("script")){let a,w=/__next_f\.push\(\[(\d+),(.*)\]\s*\)/gs;for(;(a=w.exec(r.textContent))!==null;)if(parseInt(a[1])===1)try{const u=JSON.parse(a[2]);typeof u=="string"&&$.push(u)}catch{}}const T=$.join(""),E=new Map;let z=0;for(;z<T.length;){const r=T.indexOf(":",z);if(r===-1)break;const a=T.substring(z,r);if(!/^[0-9a-f]+$/i.test(a)){const u=T.indexOf(`
`,z);z=u<0?T.length:u+1;continue}const w=T.indexOf(`
`,r+1);E.set(a,w<0?T.substring(r+1):T.substring(r+1,w)),z=w<0?T.length:w+1}const t=new Map,n=new Set(["{","[",'"',"'","-","0","1","2","3","4","5","6","7","8","9","t","f","n"]);for(const[r,a]of E)try{t.set(r,n.has(a[0])?JSON.parse(a):a)}catch{t.set(r,a)}function e(r){return r&&typeof r=="object"&&!Array.isArray(r)&&typeof r.maximumListPrice=="number"&&typeof r.minimumPromoPrice=="number"&&Array.isArray(r.sizeSet)&&Array.isArray(r.variants)&&r.variants.length>0&&r.variants[0]!==null&&Array.isArray(r.colorSet)}function o(r,a=new WeakSet,w=0){if(w>80||r==null)return null;if(typeof r=="string"){if(r.startsWith("$")&&!r.startsWith("$L")){const u=t.get(r.slice(1));if(u!=null)return o(u,a,w+1)}return null}if(typeof r!="object"||a.has(r))return null;if(a.add(r),e(r))return r;for(const u of Array.isArray(r)?r:Object.values(r)){const p=o(u,a,w+1);if(p)return p}return null}const i=o(t.get("c"));if(!i)return null;const s=new URLSearchParams(window.location.search).get("skuid"),l=i.variants.map(r=>({skuId:r.skuId,colorName:r.colorName??null}));return{id:i.id,hasColor:i.colorSet.length>0,selectedVariant:l.find(r=>r.skuId===s)??l[0]??null}}function d(){const $=document.querySelector("h1");if(!$)return null;const T=Object.keys($).find(z=>z.startsWith("__reactFiber"));if(!T)return null;let E=$[T];for(;E;){const z=E.memoizedProps;if(z&&z.product&&typeof z.product.id<"u"){const t=z.product,n=new URLSearchParams(window.location.search).get("skuid"),e=(t.variants||[]).filter(o=>o).map(o=>({skuId:o.skuId,colorName:o.colorName??null}));return{id:t.id,hasColor:Array.isArray(t.colorSet)&&t.colorSet.length>0,selectedVariant:e.find(o=>o.skuId===n)??e[0]??null}}E=E.return}return null}const y=window.location.pathname.split("/").filter(Boolean).pop(),g=h();if(g&&g.id===y)return g;const k=d();if(k)return k;if(g)return g;throw new Error("Product not found")}function v(h,d){if(!h)return{color:void 0,productId:void 0};const y=h?.variants,g=y.findIndex(T=>T.clothingBrandColor?c(T.clothingBrandColor)===c(d):c(T.color)===c(d)),k=g<0?0:g;return y[k]?.color}function N(){let h;return document.querySelector(".attributeAccordionText")?.innerText.includes("Color")&&(h=document.querySelector(".attributeAccordionTextValue")?.textContent?.trim()),{elementColor:h}}function Q(){jml.logs=jml.logs??[];const{elementColor:h}=N();if(!h)return;if(window.next.router.components["/tienda/oneColumnPage"].props.pageProps.initialPropsData)return v(window.next.router.components["/tienda/oneColumnPage"].props.pageProps.initialPropsData.mainContent.records[0].allMeta,h);const d=JSON.parse(document.querySelector("#__NEXT_DATA__")?.innerText);return v(d.query?.data?.mainContent?.records?.at(0)?.allMeta,h)}try{if(window?.jml?.isStaging){const y=x();if(!y)return"empty";if(y.hasColor){const g=c(y.selectedVariant.colorName);return`${y.id}_${g}`}return y.id}let h=window.location.pathname.split("/").pop();if(!h)return"empty";let d=Q();return d?(d=c(d),`${h}_${d}`):h}catch{return"empty"}})()||"";b!==window.jml.item_id&&(window.jml.item_id=b,jml.renderPlacements(jml))}catch(b){jml.debug().log("failed to load __jml_item_id",b)}jml.currentUrl!==window.location.href&&(clearTimeout(j),j=setTimeout(()=>{jml.item_url=window.location.pathname,jml.currentUrl=window.location.href,jml.carouselRendered=!1,jml.noRecs=!1,jml.tries=0,A()},1e3)),C.forEach(b=>{b.type==="childList"&&(Array.from(b.addedNodes).forEach(c=>{c.nodeType===1&&U().some(N=>{try{return!!(c.matches&&c.matches(N)||c.querySelector&&c.querySelector(N))}catch{return!1}})&&(document.querySelectorAll("div[id$='jml-carousel']").forEach(N=>{N.remove()}),A(c))}),Array.from(b.removedNodes).forEach(c=>{if(c.nodeType===1){const x=c.id&&typeof c.id=="string"&&c.id.includes("jml-carousel"),v=!x&&c.querySelector&&!!c.querySelector("div[id$='jml-carousel']");(x||v)&&(jml.carouselRemoved=!0,A(null,"removed"))}}))})});return window.jml.observers.set(M,D),D.observe(M,{subtree:!0,childList:!0}),D}function U(){var A=[];return jml.layoutSectionsMap?Object.keys(jml.layoutSectionsMap).forEach(L=>{(jml.layoutSectionsMap[L]||[]).forEach(j=>{j.active!==!1&&j.exact_target_selector&&A.push(j.exact_target_selector)})}):jml.routesObject&&Object.keys(jml.routesObject).forEach(L=>{(jml.routesObject[L]||[]).forEach(j=>{(j.associated_sections||[]).forEach(M=>{M.active!==!1&&M.section&&M.section.exact_target_selector&&A.push(M.section.exact_target_selector)})})}),A}var q=(A,L)=>{if(jml.debug().log("jml_carousel_called"),L==="removed"){try{window.jml.item_id=(()=>{function j(c){return c!=null&&(c=c.toLowerCase(),c=c.normalize("NFKD"),c=c.replace(/[\u0300-\u036f]/g,""),c=c.replace(/\s+/g,"_")),c}function M(){function c(){const h=window.__next_f.filter(e=>Array.isArray(e)&&e[0]===1&&typeof e[1]=="string").map(e=>e[1]);for(const e of document.querySelectorAll("script")){let o,i=/__next_f\.push\(\[(\d+),(.*)\]\s*\)/gs;for(;(o=i.exec(e.textContent))!==null;)if(parseInt(o[1])===1)try{const s=JSON.parse(o[2]);typeof s=="string"&&h.push(s)}catch{}}const d=h.join(""),y=new Map;let g=0;for(;g<d.length;){const e=d.indexOf(":",g);if(e===-1)break;const o=d.substring(g,e);if(!/^[0-9a-f]+$/i.test(o)){const s=d.indexOf(`
`,g);g=s<0?d.length:s+1;continue}const i=d.indexOf(`
`,e+1);y.set(o,i<0?d.substring(e+1):d.substring(e+1,i)),g=i<0?d.length:i+1}const k=new Map,$=new Set(["{","[",'"',"'","-","0","1","2","3","4","5","6","7","8","9","t","f","n"]);for(const[e,o]of y)try{k.set(e,$.has(o[0])?JSON.parse(o):o)}catch{k.set(e,o)}function T(e){return e&&typeof e=="object"&&!Array.isArray(e)&&typeof e.maximumListPrice=="number"&&typeof e.minimumPromoPrice=="number"&&Array.isArray(e.sizeSet)&&Array.isArray(e.variants)&&e.variants.length>0&&e.variants[0]!==null&&Array.isArray(e.colorSet)}function E(e,o=new WeakSet,i=0){if(i>80||e==null)return null;if(typeof e=="string"){if(e.startsWith("$")&&!e.startsWith("$L")){const s=k.get(e.slice(1));if(s!=null)return E(s,o,i+1)}return null}if(typeof e!="object"||o.has(e))return null;if(o.add(e),T(e))return e;for(const s of Array.isArray(e)?e:Object.values(e)){const l=E(s,o,i+1);if(l)return l}return null}const z=E(k.get("c"));if(!z)return null;const t=new URLSearchParams(window.location.search).get("skuid"),n=z.variants.map(e=>({skuId:e.skuId,colorName:e.colorName??null}));return{id:z.id,hasColor:z.colorSet.length>0,selectedVariant:n.find(e=>e.skuId===t)??n[0]??null}}function x(){const h=document.querySelector("h1");if(!h)return null;const d=Object.keys(h).find(g=>g.startsWith("__reactFiber"));if(!d)return null;let y=h[d];for(;y;){const g=y.memoizedProps;if(g&&g.product&&typeof g.product.id<"u"){const k=g.product,$=new URLSearchParams(window.location.search).get("skuid"),T=(k.variants||[]).filter(E=>E).map(E=>({skuId:E.skuId,colorName:E.colorName??null}));return{id:k.id,hasColor:Array.isArray(k.colorSet)&&k.colorSet.length>0,selectedVariant:T.find(E=>E.skuId===$)??T[0]??null}}y=y.return}return null}const v=window.location.pathname.split("/").filter(Boolean).pop(),N=c();if(N&&N.id===v)return N;const Q=x();if(Q)return Q;if(N)return N;throw new Error("Product not found")}function D(c,x){if(!c)return{color:void 0,productId:void 0};const v=c?.variants,N=v.findIndex(d=>d.clothingBrandColor?j(d.clothingBrandColor)===j(x):j(d.color)===j(x)),Q=N<0?0:N;return v[Q]?.color}function C(){let c;return document.querySelector(".attributeAccordionText")?.innerText.includes("Color")&&(c=document.querySelector(".attributeAccordionTextValue")?.textContent?.trim()),{elementColor:c}}function b(){jml.logs=jml.logs??[];const{elementColor:c}=C();if(!c)return;if(window.next.router.components["/tienda/oneColumnPage"].props.pageProps.initialPropsData)return D(window.next.router.components["/tienda/oneColumnPage"].props.pageProps.initialPropsData.mainContent.records[0].allMeta,c);const x=JSON.parse(document.querySelector("#__NEXT_DATA__")?.innerText);return D(x.query?.data?.mainContent?.records?.at(0)?.allMeta,c)}try{if(window?.jml?.isStaging){const v=M();if(!v)return"empty";if(v.hasColor){const N=j(v.selectedVariant.colorName);return`${v.id}_${N}`}return v.id}let c=window.location.pathname.split("/").pop();if(!c)return"empty";let x=b();return x?(x=j(x),`${c}_${x}`):c}catch{return"empty"}})()||"empty"}catch(j){jml.debug().log("failed to load __jml_item_id",j),window.jml.item_id="empty"}jml.carouselRendered=!1,jml.tries=0,jml.renderPlacements(jml);return}try{try{window.jml.item_id=(()=>{function j(c){return c!=null&&(c=c.toLowerCase(),c=c.normalize("NFKD"),c=c.replace(/[\u0300-\u036f]/g,""),c=c.replace(/\s+/g,"_")),c}function M(){function c(){const h=window.__next_f.filter(e=>Array.isArray(e)&&e[0]===1&&typeof e[1]=="string").map(e=>e[1]);for(const e of document.querySelectorAll("script")){let o,i=/__next_f\.push\(\[(\d+),(.*)\]\s*\)/gs;for(;(o=i.exec(e.textContent))!==null;)if(parseInt(o[1])===1)try{const s=JSON.parse(o[2]);typeof s=="string"&&h.push(s)}catch{}}const d=h.join(""),y=new Map;let g=0;for(;g<d.length;){const e=d.indexOf(":",g);if(e===-1)break;const o=d.substring(g,e);if(!/^[0-9a-f]+$/i.test(o)){const s=d.indexOf(`
`,g);g=s<0?d.length:s+1;continue}const i=d.indexOf(`
`,e+1);y.set(o,i<0?d.substring(e+1):d.substring(e+1,i)),g=i<0?d.length:i+1}const k=new Map,$=new Set(["{","[",'"',"'","-","0","1","2","3","4","5","6","7","8","9","t","f","n"]);for(const[e,o]of y)try{k.set(e,$.has(o[0])?JSON.parse(o):o)}catch{k.set(e,o)}function T(e){return e&&typeof e=="object"&&!Array.isArray(e)&&typeof e.maximumListPrice=="number"&&typeof e.minimumPromoPrice=="number"&&Array.isArray(e.sizeSet)&&Array.isArray(e.variants)&&e.variants.length>0&&e.variants[0]!==null&&Array.isArray(e.colorSet)}function E(e,o=new WeakSet,i=0){if(i>80||e==null)return null;if(typeof e=="string"){if(e.startsWith("$")&&!e.startsWith("$L")){const s=k.get(e.slice(1));if(s!=null)return E(s,o,i+1)}return null}if(typeof e!="object"||o.has(e))return null;if(o.add(e),T(e))return e;for(const s of Array.isArray(e)?e:Object.values(e)){const l=E(s,o,i+1);if(l)return l}return null}const z=E(k.get("c"));if(!z)return null;const t=new URLSearchParams(window.location.search).get("skuid"),n=z.variants.map(e=>({skuId:e.skuId,colorName:e.colorName??null}));return{id:z.id,hasColor:z.colorSet.length>0,selectedVariant:n.find(e=>e.skuId===t)??n[0]??null}}function x(){const h=document.querySelector("h1");if(!h)return null;const d=Object.keys(h).find(g=>g.startsWith("__reactFiber"));if(!d)return null;let y=h[d];for(;y;){const g=y.memoizedProps;if(g&&g.product&&typeof g.product.id<"u"){const k=g.product,$=new URLSearchParams(window.location.search).get("skuid"),T=(k.variants||[]).filter(E=>E).map(E=>({skuId:E.skuId,colorName:E.colorName??null}));return{id:k.id,hasColor:Array.isArray(k.colorSet)&&k.colorSet.length>0,selectedVariant:T.find(E=>E.skuId===$)??T[0]??null}}y=y.return}return null}const v=window.location.pathname.split("/").filter(Boolean).pop(),N=c();if(N&&N.id===v)return N;const Q=x();if(Q)return Q;if(N)return N;throw new Error("Product not found")}function D(c,x){if(!c)return{color:void 0,productId:void 0};const v=c?.variants,N=v.findIndex(d=>d.clothingBrandColor?j(d.clothingBrandColor)===j(x):j(d.color)===j(x)),Q=N<0?0:N;return v[Q]?.color}function C(){let c;return document.querySelector(".attributeAccordionText")?.innerText.includes("Color")&&(c=document.querySelector(".attributeAccordionTextValue")?.textContent?.trim()),{elementColor:c}}function b(){jml.logs=jml.logs??[];const{elementColor:c}=C();if(!c)return;if(window.next.router.components["/tienda/oneColumnPage"].props.pageProps.initialPropsData)return D(window.next.router.components["/tienda/oneColumnPage"].props.pageProps.initialPropsData.mainContent.records[0].allMeta,c);const x=JSON.parse(document.querySelector("#__NEXT_DATA__")?.innerText);return D(x.query?.data?.mainContent?.records?.at(0)?.allMeta,c)}try{if(window?.jml?.isStaging){const v=M();if(!v)return"empty";if(v.hasColor){const N=j(v.selectedVariant.colorName);return`${v.id}_${N}`}return v.id}let c=window.location.pathname.split("/").pop();if(!c)return"empty";let x=b();return x?(x=j(x),`${c}_${x}`):c}catch{return"empty"}})()||"empty"}catch(j){jml.debug().log("failed to load __jml_item_id",j),window.jml.item_id="empty"}jml.renderPlacements(jml),(()=>{function j(D){return D.replace(/\//g,"/")}if(Object.keys(jml.routesObject).filter(D=>D!=="/").some(D=>{try{return jml.pathToRegex(j(D)).test(location.pathname)}catch(C){return console.warn("Invalid pattern:",D,C),!1}})&&window.jml.item_id&&window.jml.item_id!=="undefined"&&window.jml.item_id!=="null"&&window.location.pathname!=="/"){const D=localStorage.getItem("jml_recently_viewed_items_67fd95260740ccc4ec658d03"),C=D?D.split(","):[],b=window.jml.item_id==="empty"?encodeURIComponent(window.jml.item_url):window.jml.item_id;let c="";if(C.length===0)c=b.toString();else{const x=C.filter(v=>v!==b.toString());x.unshift(b),c=x.slice(0,20).join(",")}localStorage.setItem("jml_recently_viewed_items_67fd95260740ccc4ec658d03",c)}})()}catch{}jml.tries+=1},S=_((A,L)=>{jml.carouselRemoved&&(L="removed",jml.carouselRemoved=!1),!(jml.renderInProgress||jml.serviceDown||jml.tries>=jml.maxTries||jml.noRecs||jml.carouselRendered&&L!=="removed")&&q(A,L)},500);function P(A,L=1e4){return new Promise((j,M)=>{if(!A||typeof A!="string"){M(new Error("waitForElement selector must be a non-empty string"));return}let D;try{D=document.querySelector(A)}catch(c){M(c);return}if(D){j(D);return}const C=new MutationObserver(()=>{let c;try{c=document.querySelector(A)}catch(x){clearTimeout(b),C.disconnect(),M(x);return}c&&(clearTimeout(b),C.disconnect(),j(c))});C.observe(document.documentElement,{childList:!0,subtree:!0});const b=setTimeout(()=>{C.disconnect(),M(new Error(`Element ${A} not found within ${L}ms`))},L)})}async function F(){jml.debug().log("r.js delayedRender call"),await P("",1e4).then(()=>{jml.debug().log("r.js Element found")}).catch(j=>{jml.debug().log("r.js Element NOT found",j)}).finally(()=>{jml.debug().log("r.js Rendering placements"),O(S),jml.renderPlacements(jml)})}O(S),S()},0)}function ie(H,_,R){var O=document.querySelector('script[src="'+H+'"]');if(O){if(O.getAttribute("data-jml-loaded")==="1"||H.indexOf("swiper")>-1&&window.Swiper){_();return}O.addEventListener("load",function(){_()}),O.addEventListener("error",function(){_()});return}var U=document.createElement("script");U.src=H,U.onload=function(){U.setAttribute("data-jml-loaded","1"),_()},U.onerror=function(){if(R){var q=document.createElement("script");q.src=R,q.onload=function(){q.setAttribute("data-jml-loaded","1"),_()},q.onerror=function(){_()},q.crossOrigin="anonymous",K.appendChild(q)}else _()},U.crossOrigin="anonymous",K.appendChild(U)}ie("https://cdn.jsdelivr.net/npm/swiper@12.1.2/swiper-bundle.min.js",function(){ie("https://rerender.jewelml.io/r/d/core.web.min.js",re)},"https://rerender.jewelml.io/lib/swiper-bundle.min.js")})();
